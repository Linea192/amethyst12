# TessXract — Amethyst core, Dopamine-style UI

**Amethyst (iOS 12–13 jailbreak by staturnz) with the full Dopamine user interface.
Same Amethyst inside, Dopamine outside.**

---

## What this is

A complete re-skin of [Amethyst](https://github.com/staturnzz/amethyst) so that it
looks and behaves visually like [Dopamine](https://github.com/opa334/dopamine)
(opa334's iOS 15–16 jailbreak), while keeping 100% of Amethyst's jailbreak
logic untouched:

- Hemlock / Trigon kernel exploits
- Bootstrap, Sileo / Zebra / libswift installation
- RootFS remount / restore, Enable Tweaks
- Generator handling, Trigon offset cache
- All error handling and reboot flows
- Config persistence (`config.plist`) — **existing configs remain compatible**

## Licensing / attribution

- Amethyst — MIT License, © 2026 staturnz
- Dopamine — MIT License, © 2023-2024 Lars Fröder (opa334)

The UI layer in `Amethyst/ui/dopamine/` is a port of Dopamine's UI code
(written mostly by tomt000 and opa334) with adaptations for this project.
Both licenses permit this reuse with attribution, which is kept in every
ported file's header and in the in-app Credits page.

## The new interface

| Screen | Now looks like |
|---|---|
| Main screen | Dopamine wordmark header + "iOS 12 – 13 / Made by staturnz" subtitles, action-menu card (Settings / Respring Device / Userspace Reboot / Credits), big rounded **Jailbreak** button |
| Jailbreak run | Button expands to a full-screen log: "Jailbreaking" title, double-helix indicator, Apple-Music-lyrics-style progress lines with spinner → checkmark animation |
| Settings | Dopamine-style card list, pushed as a centered modal that scales in (tap outside to dismiss) |
| Exploit / Theme pickers | Card list with checkmarks |
| Generator | Card with monospaced editor + Save, same 0x… validation as before |
| Credits | Card table, now also crediting op334 & tomt000 for the UI |
| Alerts (errors, install picker, icon-cache) | Dark rounded cards with the Dopamine menu color |

Respring / Userspace Reboot rows are enabled only when jailbroken, exactly like
Dopamine's menu behavior.

## Themes

Five themes in `ui/dopamine/Themes.plist` (Dopamine's theme system, ported):

| Key | Background |
|---|---|
| `dopamine` (default) | Dopamine's green background (blurred 18) |
| `amethyst` / `citrus` / `dusk` / `oxide` | Amethyst's original backgrounds, restyled with Dopamine colors |

Legacy configs saved with theme names `Amethyst`, `Citrus`, `Dusk` or `Oxide`
map to the matching new theme automatically (case-insensitive key lookup).
Changing a theme rebuilds the UI in place, like Dopamine's relaunch.

## iOS 12 compatibility (downport notes)

Amethyst's deployment target is iOS 12.0, so Dopamine's iOS 15+ APIs were
replaced 1:1 with classic equivalents:

| Dopamine (iOS 15+) | This port (iOS 12-safe) |
|---|---|
| `UIButtonConfiguration` | classic `UIButton` styling (font/colors/insets) |
| `UIAction`-based buttons | `DOActionMenuItem` (title, icon name, handler block) |
| SF Symbols | loaded on iOS 13+; on iOS 12 buttons fall back to text-only |
| `kCACornerCurveContinuous` | guarded with `@available(iOS 13.0, *)` |
| `overrideUserInterfaceStyle` | guarded with `@available(iOS 13.0, *)` |
| Progressive blur on log view | omitted (private `CAFilter` API) |

Everything else — layout metrics (`UI_PADDING 30`, action row height 73,
corner radius 14, menu color `#3F3F3F` @ 45%, window color `#4C4C4C` @ 60%,
spring animations, modal transitions) — matches Dopamine exactly.

## Files

**New — ported Dopamine UI** (`Amethyst/ui/dopamine/`):

| File | Contents |
|---|---|
| `DOGlobalAppearance.h/.m` | design tokens, attributed subtitles, device helpers |
| `UIImage+Blur.h/.m` | background blur (CIGaussianBlur) |
| `DOTheme.h/.m` | theme model (colors, image, blur radius) |
| `DOThemeManager.h/.m` | theme list + enabled theme from Amethyst's config |
| `Themes.plist` | the five themes |
| `DOActionMenu.h/.m` | `DOActionMenuItem` + action-menu card + menu buttons |
| `DOHeaderView.h/.m` | logo + subtitles header |
| `DOLogView.h/.m` | lyrics-style log, loading + double-helix indicators |
| `DOJailbreakButton.h/.m` | big button, expand-to-fullscreen, title + helix |
| `DOTransitions.h/.m` | modal scale/push transitions, outside-tap back action |
| `DONavigationController.h/.m` | theme background, modal presentation, dimming |
| `AMSettingsController.h/.m` | new Dopamine-style settings screen |
| `AMSettingsSubcontrollers.h/.m` | checkmark picker + generator editor |

**Rewritten** (logic preserved, UI replaced):

- `ui/MainController.h/.m` — Dopamine main screen + all action methods +
  the unchanged C bridge (`ProgressLog`, `FadeDisplay`, `ShowAlert`,
  `get_install_options`, `get_app_version`)
- `ui/Utilities.h/.m` — `PopupAlert`, `InstallAlert`, `LoadingAlert`,
  `PopupOption` restyled dark (APIs unchanged)
- `ui/CreditsController.h/.m` — card table + UI credits rows
- `AppDelegate.m` — navigation controller as root, default theme `dopamine`

**Assets added** (from Dopamine, MIT): `Background_Green.imageset`,
`Dopamine.imageset` (wordmark), `Loading.imageset` (spinner).

**Removed**: the old popup-card system (`CardView`, `CardButton`, `PopupCard`,
`ProgressRing`) and the light-mode toggle (Dopamine's look is dark-only;
`lightMode` stays in the config file for compatibility but is unused).

## Building

Same as upstream Amethyst:

```bash
cd Amethyst
./buildipa.sh        # xcodebuild + ldid -> Amethyst.ipa
```

or open `Amethyst.xcodeproj` in Xcode and build the Amethyst target.
All new files are already registered in the project.

## Removed behavior notes

- The old background-image picker with live previews was replaced by the
  Dopamine-style theme list (same backgrounds available).
- "Refresh Icon Cache" now lives in Settings → Utilities (jailbroken only).

## TessXract rebrand (v3)

The UI is rebranded as **TessXract**: pixel-art moon app icon, pixel-font TessXract
wordmark (rendered natively at 1x/2x/3x so it stays perfectly crisp), and a new default
"TessXract" theme (black wallpaper with a pixel-art **meteor shower** —
diagonal streaks with bright heads and fading tails, routed around the menu
card and button so no text is obscured). App display name and all
user-visible strings now say TessXract. The "Dopamine" theme was renamed
Emerald and the "Amethyst" theme Violet. Bundle ID stays
com.staturnz.amethyst (jailbreak internals reference it).

The Credits page lists **Linea Evermont** (TessXract rebrand, logo & theme) at the
top, above the upstream authors.

Build output is now `TessXract.ipa` (see buildipa.sh / GitHub workflow).

### v4 polish

- **Icon**: crop now includes the full ring design around the moon (not just
  the disc) — the artwork fills ~90% of the icon with clean margins on every
  side, and nothing touches the rounded corners.
- **Settings/Credits/pickers on 4-inch screens**: the big title no longer
  collides with the back button — it stays centered when there is room and
  slides right of the back button otherwise (priority-999 centering +
  autoshrink). Detail rows (Theme, Exploit, Generator) show a `›` chevron and
  the value hugs the right edge; switch rows keep 12pt clear of the label.
- **Live meteor animation**: on the TessXract theme, a `CAEmitterLayer`
  (iOS 5+ API) continuously spawns pixel-art meteors near the top of the
  screen that streak down-left and fade — on every screen (main, settings,
  credits), sliding behind the translucent cards. Implemented as a private
  `TessMeteorView` class inside `DONavigationController.m`; only a handful
  of particles are alive at once, so it is cheap on old GPUs.
