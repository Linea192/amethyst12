#import "../AppDelegate.h"
#import "Utilities.h"
#import "dopamine/DOThemeManager.h"

#define AM_ALERT_WIDTH 280.0
#define AM_ALERT_RADIUS 14.0

@implementation UILabel (extensions)
+ (UILabel *)createLabel:(NSString *)text size:(CGFloat)size bold:(bool)bold align:(NSTextAlignment)align {
    UILabel *label = [[UILabel alloc] init];
    label.text = text;
    label.textColor = [UIColor whiteColor];
    label.textAlignment = align;
    label.font = bold ? [UIFont boldSystemFontOfSize:size] : [UIFont systemFontOfSize:size];
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.5;
    label.translatesAutoresizingMaskIntoConstraints = NO;
    return label;
}
@end

@implementation UIView (extensions)
+ (UIView *)createSeprator:(BOOL)unused {
    UIView *separator = [[UIView alloc] init];
    separator.backgroundColor = [UIColor colorWithWhite:0.6 alpha:0.3];
    separator.layer.cornerRadius = 0.5;
    separator.layer.masksToBounds = YES;
    separator.translatesAutoresizingMaskIntoConstraints = NO;
    return separator;
}
@end

#pragma mark - PopupOption (switch row)

@implementation PopupOption

- (id)initSwitchOption:(NSString *)title {
    self = [super init];

    self.optionView = [[UIView alloc] init];
    self.optionView.translatesAutoresizingMaskIntoConstraints = NO;

    self.optionTitle = [[UILabel alloc] init];
    self.optionTitle.text = title;
    self.optionTitle.textColor = [UIColor whiteColor];
    self.optionTitle.font = [UIFont systemFontOfSize:17];
    self.optionTitle.translatesAutoresizingMaskIntoConstraints = NO;
    [self.optionView addSubview:self.optionTitle];

    self.optionSwitch = [[UISwitch alloc] init];
    self.optionSwitch.translatesAutoresizingMaskIntoConstraints = NO;
    self.optionSwitch.onTintColor = [UIColor colorWithRed:0.30 green:0.85 blue:0.39 alpha:1.0];
    [self.optionView addSubview:self.optionSwitch];

    self.separator = [UIView createSeprator:NO];
    self.separator.hidden = YES;
    [self.optionView addSubview:self.separator];

    [NSLayoutConstraint activateConstraints:@[
        [self.optionTitle.leadingAnchor constraintEqualToAnchor:self.optionView.leadingAnchor constant:20],
        [self.optionTitle.centerYAnchor constraintEqualToAnchor:self.optionView.centerYAnchor],
        [self.optionSwitch.trailingAnchor constraintEqualToAnchor:self.optionView.trailingAnchor constant:-20],
        [self.optionSwitch.centerYAnchor constraintEqualToAnchor:self.optionView.centerYAnchor],
        [self.separator.leadingAnchor constraintEqualToAnchor:self.optionView.leadingAnchor constant:10],
        [self.separator.trailingAnchor constraintEqualToAnchor:self.optionView.trailingAnchor constant:-10],
        [self.separator.bottomAnchor constraintEqualToAnchor:self.optionView.bottomAnchor],
        [self.separator.heightAnchor constraintEqualToConstant:1],
    ]];

    return self;
}

- (void)showSeprator:(BOOL)val {
    self.separator.hidden = !val;
}

- (BOOL)getSwitchValue {
    return self.optionSwitch.on;
}

- (void)setSwitchValue:(BOOL)val {
    [self.optionSwitch setOn:val animated:NO];
}

- (void)setSwitchCallback:(id)_id _sel:(SEL)_sel {
    [self.optionSwitch addTarget:_id action:_sel forControlEvents:UIControlEventValueChanged];
}

@end

#pragma mark - PopupAlert

@implementation PopupAlert

- (id)init:(NSString *)title message:(NSString *)message button:(NSString *)button _id:(id)_id _sel:(SEL)_sel {
    self = [super init];

    self.alertView = [[UIView alloc] init];
    self.alertView.translatesAutoresizingMaskIntoConstraints = NO;
    self.alertView.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
    self.alertView.layer.cornerRadius = AM_ALERT_RADIUS;
    self.alertView.layer.masksToBounds = YES;
    if (@available(iOS 13.0, *)) {
        self.alertView.layer.cornerCurve = kCACornerCurveContinuous;
    }
    self.alertView.transform = CGAffineTransformScale(CGAffineTransformMakeTranslation(0, 0), 1.2, 1.2);
    self.alertView.alpha = 0.0;

    self.alertTitle = [UILabel createLabel:title size:20 bold:YES align:NSTextAlignmentCenter];
    self.alertMessage = [UILabel createLabel:message size:14 bold:NO align:NSTextAlignmentCenter];
    self.alertMessage.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.8];
    self.alertMessage.numberOfLines = 0;

    self.separator = [UIView createSeprator:NO];

    self.alertButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.alertButton setTitle:button forState:UIControlStateNormal];
    [self.alertButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.alertButton setTitleColor:[[UIColor whiteColor] colorWithAlphaComponent:0.5] forState:UIControlStateDisabled];
    self.alertButton.titleLabel.font = [UIFont systemFontOfSize:17];
    self.alertButton.layer.borderWidth = 1.0;
    self.alertButton.layer.cornerRadius = 12.0;
    self.alertButton.layer.masksToBounds = YES;
    self.alertButton.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.60].CGColor;
    [self.alertButton addTarget:_id action:_sel forControlEvents:UIControlEventTouchUpInside];
    self.alertButton.translatesAutoresizingMaskIntoConstraints = NO;

    [self.alertView addSubview:self.alertTitle];
    [self.alertView addSubview:self.alertMessage];
    [self.alertView addSubview:self.separator];
    [self.alertView addSubview:self.alertButton];

    [NSLayoutConstraint activateConstraints:@[
        [self.alertTitle.centerXAnchor constraintEqualToAnchor:self.alertView.centerXAnchor],
        [self.alertTitle.topAnchor constraintEqualToAnchor:self.alertView.topAnchor constant:20],
        [self.alertMessage.centerXAnchor constraintEqualToAnchor:self.alertView.centerXAnchor],
        [self.alertMessage.topAnchor constraintEqualToAnchor:self.alertTitle.bottomAnchor constant:10],
        [self.alertMessage.widthAnchor constraintEqualToAnchor:self.alertView.widthAnchor constant:-40],
        [self.separator.topAnchor constraintEqualToAnchor:self.alertMessage.bottomAnchor constant:15],
        [self.separator.leadingAnchor constraintEqualToAnchor:self.alertView.leadingAnchor constant:20],
        [self.separator.trailingAnchor constraintEqualToAnchor:self.alertView.trailingAnchor constant:-20],
        [self.separator.heightAnchor constraintEqualToConstant:1],
        [self.alertButton.topAnchor constraintEqualToAnchor:self.separator.bottomAnchor constant:15],
        [self.alertButton.bottomAnchor constraintEqualToAnchor:self.alertView.bottomAnchor constant:-20],
        [self.alertButton.leadingAnchor constraintEqualToAnchor:self.alertView.leadingAnchor constant:20],
        [self.alertButton.trailingAnchor constraintEqualToAnchor:self.alertView.trailingAnchor constant:-20],
        [self.alertButton.heightAnchor constraintEqualToConstant:40],
    ]];

    return self;
}

- (void)setText:(NSString *)title message:(NSString *)message button:(NSString *)button {
    self.alertTitle.text = title;
    self.alertMessage.text = message;
    [self.alertButton setTitle:button forState:UIControlStateNormal];
}

- (void)setAction:(id)_id _sel:(SEL)_sel {
    [self.alertButton removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
    [self.alertButton addTarget:_id action:_sel forControlEvents:UIControlEventTouchUpInside];
}

- (void)setOverlay:(UIView *)view {
    self.alertOverlay = view;
}

- (void)openAlert {
    [UIView animateWithDuration:0.3 animations:^{
        self.alertView.alpha = 0.95;
        self.alertView.transform = CGAffineTransformScale(CGAffineTransformMakeTranslation(0, 0), 1.0, 1.0);
        if (self.alertOverlay != NULL) self.alertOverlay.alpha = 0.65f;
    }];
}

- (void)closeAlert {
    [UIView animateWithDuration:0.3 animations:^{
        self.alertView.alpha = 0.0;
        self.alertView.transform = CGAffineTransformScale(CGAffineTransformMakeTranslation(0, 0), 1.2, 1.2);
        if (self.alertOverlay != NULL) self.alertOverlay.alpha = 0.0f;
    }];
}

- (BOOL)isOpen {
    return (self.alertView.alpha > 0.5f);
}

@end

#pragma mark - InstallAlert

@implementation InstallAlert

- (id)init {
    self = [super init];

    self.alertView = [[UIView alloc] init];
    self.alertView.translatesAutoresizingMaskIntoConstraints = NO;
    self.alertView.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
    self.alertView.layer.cornerRadius = AM_ALERT_RADIUS;
    self.alertView.layer.masksToBounds = YES;
    if (@available(iOS 13.0, *)) {
        self.alertView.layer.cornerCurve = kCACornerCurveContinuous;
    }
    self.alertView.transform = CGAffineTransformScale(CGAffineTransformMakeTranslation(0, 0), 1.2, 1.2);
    self.alertView.alpha = 0.0;

    self.alertTitle = [UILabel createLabel:@"Configure Install" size:20 bold:YES align:NSTextAlignmentCenter];

    self.alertMessage = [UILabel createLabel:@"Choose what to install" size:14 bold:NO align:NSTextAlignmentCenter];
    self.alertMessage.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.8];

    self.separator = [UIView createSeprator:NO];

    self.alertButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.alertButton setTitle:@"Okay" forState:UIControlStateNormal];
    [self.alertButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.alertButton setTitleColor:[[UIColor whiteColor] colorWithAlphaComponent:0.5] forState:UIControlStateDisabled];
    self.alertButton.titleLabel.font = [UIFont systemFontOfSize:17];
    self.alertButton.layer.borderWidth = 1.0;
    self.alertButton.layer.cornerRadius = 12.0;
    self.alertButton.layer.masksToBounds = YES;
    self.alertButton.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.60].CGColor;
    [self.alertButton addTarget:self action:@selector(closeAlert) forControlEvents:UIControlEventTouchUpInside];
    self.alertButton.translatesAutoresizingMaskIntoConstraints = NO;

    [self.alertView addSubview:self.alertTitle];
    [self.alertView addSubview:self.alertMessage];
    [self.alertView addSubview:self.separator];
    [self.alertView addSubview:self.alertButton];

    self.installSileo = [[PopupOption alloc] initSwitchOption:@"Install Sileo"];
    self.installZebra = [[PopupOption alloc] initSwitchOption:@"Install Zebra"];
    [self.installSileo setSwitchValue:true];
    [self.installZebra setSwitchValue:true];
    [self.installSileo showSeprator:YES];
    [self.installZebra showSeprator:NO];

    [self.alertView addSubview:self.installSileo.optionView];
    [self.alertView addSubview:self.installZebra.optionView];

    [self.installSileo.optionSwitch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    [self.installZebra.optionSwitch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];

    [NSLayoutConstraint activateConstraints:@[
        [self.alertTitle.centerXAnchor constraintEqualToAnchor:self.alertView.centerXAnchor],
        [self.alertTitle.topAnchor constraintEqualToAnchor:self.alertView.topAnchor constant:20],

        [self.alertMessage.centerXAnchor constraintEqualToAnchor:self.alertView.centerXAnchor],
        [self.alertMessage.topAnchor constraintEqualToAnchor:self.alertTitle.bottomAnchor constant:5],

        [self.separator.topAnchor constraintEqualToAnchor:self.alertMessage.bottomAnchor constant:15],
        [self.separator.leadingAnchor constraintEqualToAnchor:self.alertView.leadingAnchor constant:20],
        [self.separator.trailingAnchor constraintEqualToAnchor:self.alertView.trailingAnchor constant:-20],
        [self.separator.heightAnchor constraintEqualToConstant:1],

        [self.installSileo.optionView.topAnchor constraintEqualToAnchor:self.separator.bottomAnchor constant:5],
        [self.installSileo.optionView.leadingAnchor constraintEqualToAnchor:self.alertView.leadingAnchor],
        [self.installSileo.optionView.trailingAnchor constraintEqualToAnchor:self.alertView.trailingAnchor],
        [self.installSileo.optionView.heightAnchor constraintEqualToConstant:50],

        [self.installZebra.optionView.topAnchor constraintEqualToAnchor:self.installSileo.optionView.bottomAnchor],
        [self.installZebra.optionView.leadingAnchor constraintEqualToAnchor:self.alertView.leadingAnchor],
        [self.installZebra.optionView.trailingAnchor constraintEqualToAnchor:self.alertView.trailingAnchor],
        [self.installZebra.optionView.heightAnchor constraintEqualToConstant:50],

        [self.alertButton.topAnchor constraintEqualToAnchor:self.installZebra.optionView.bottomAnchor constant:15],
        [self.alertButton.bottomAnchor constraintEqualToAnchor:self.alertView.bottomAnchor constant:-20],
        [self.alertButton.leadingAnchor constraintEqualToAnchor:self.alertView.leadingAnchor constant:20],
        [self.alertButton.trailingAnchor constraintEqualToAnchor:self.alertView.trailingAnchor constant:-20],
        [self.alertButton.heightAnchor constraintEqualToConstant:40],
    ]];

    return self;
}

- (void)switchAction:(UISwitch *)toggle {
    if (![self.installSileo getSwitchValue] && ![self.installZebra getSwitchValue]) {
        [self.alertButton setTitleColor:[[UIColor whiteColor] colorWithAlphaComponent:0.4f] forState:UIControlStateNormal];
        self.alertButton.enabled = NO;
    } else {
        [self.alertButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        self.alertButton.enabled = YES;
    }
}

- (void)setOverlay:(UIView *)view {
    self.alertOverlay = view;
    self.alertOverlay.alpha = 0.0f;
}

- (void)openAlert {
    self.selectionDone = NO;
    [UIView animateWithDuration:0.3 animations:^{
        self.alertView.alpha = 0.95;
        self.alertView.transform = CGAffineTransformScale(CGAffineTransformMakeTranslation(0, 0), 1.0, 1.0);
        if (self.alertOverlay != NULL) self.alertOverlay.alpha = 0.65f;
    }];
}

- (void)closeAlert {
    self.selectionDone = YES;
    [UIView animateWithDuration:0.3 animations:^{
        self.alertView.alpha = 0.0;
        self.alertView.transform = CGAffineTransformScale(CGAffineTransformMakeTranslation(0, 0), 1.2, 1.2);
        if (self.alertOverlay != NULL) self.alertOverlay.alpha = 0.0f;
    }];
}

- (BOOL)isOpen {
    return (self.alertView.alpha > 0.5f);
}

@end

#pragma mark - LoadingAlert

@implementation LoadingAlert

- (id)init:(NSString *)title {
    self = [super init];

    self.alertView = [[UIView alloc] init];
    self.alertView.translatesAutoresizingMaskIntoConstraints = NO;
    self.alertView.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
    self.alertView.layer.cornerRadius = AM_ALERT_RADIUS;
    self.alertView.layer.masksToBounds = YES;
    if (@available(iOS 13.0, *)) {
        self.alertView.layer.cornerCurve = kCACornerCurveContinuous;
    }
    self.alertView.alpha = 0.0;

    self.alertTitle = [UILabel createLabel:title size:17 bold:YES align:NSTextAlignmentCenter];

    self.indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    self.indicator.translatesAutoresizingMaskIntoConstraints = NO;
    self.indicator.hidesWhenStopped = NO;
    self.indicator.color = [UIColor whiteColor];

    self.separator = [UIView createSeprator:NO];

    [self.alertView addSubview:self.alertTitle];
    [self.alertView addSubview:self.separator];
    [self.alertView addSubview:self.indicator];

    [NSLayoutConstraint activateConstraints:@[
        [self.alertTitle.centerXAnchor constraintEqualToAnchor:self.alertView.centerXAnchor],
        [self.alertTitle.topAnchor constraintEqualToAnchor:self.alertView.topAnchor constant:20],

        [self.separator.topAnchor constraintEqualToAnchor:self.alertTitle.bottomAnchor constant:15],
        [self.separator.leadingAnchor constraintEqualToAnchor:self.alertView.leadingAnchor constant:20],
        [self.separator.trailingAnchor constraintEqualToAnchor:self.alertView.trailingAnchor constant:-20],
        [self.separator.heightAnchor constraintEqualToConstant:1],

        [self.indicator.centerXAnchor constraintEqualToAnchor:self.alertView.centerXAnchor],
        [self.indicator.topAnchor constraintEqualToAnchor:self.separator.bottomAnchor constant:15],
        [self.indicator.bottomAnchor constraintEqualToAnchor:self.alertView.bottomAnchor constant:-20],
    ]];

    return self;
}

- (void)setOverlay:(UIView *)view {
    self.alertOverlay = view;
    self.alertOverlay.alpha = 0.0f;
}

- (void)openAlert {
    [self.indicator startAnimating];
    [UIView animateWithDuration:0.3 animations:^{
        self.alertView.alpha = 0.95;
        if (self.alertOverlay != NULL) self.alertOverlay.alpha = 0.65f;
    }];
}

- (void)closeAlert {
    [UIView animateWithDuration:0.3 animations:^{
        self.alertView.alpha = 0.0;
        if (self.alertOverlay != NULL) self.alertOverlay.alpha = 0.0f;
    } completion:^(BOOL finished) {
        [self.indicator stopAnimating];
    }];
}

- (BOOL)isOpen {
    return (self.alertView.alpha > 0.5f);
}

@end
