#ifndef MainController_h
#define MainController_h

#import <UIKit/UIKit.h>
#import "../AppDelegate.h"
#import "CreditsController.h"
#import "Utilities.h"
#import "dopamine/DOActionMenu.h"
#import "dopamine/DOJailbreakButton.h"
#import "dopamine/DOHeaderView.h"
#import "dopamine/DOLogView.h"

// Main screen of the app, rebuilt with the Dopamine interface.
// All jailbreak logic (exploits, bootstrap, install options, error
// handling) is unchanged Amethyst code living in the action methods.

@interface MainController : UIViewController <DOActionMenuDelegate>

@property (nonatomic, strong) DOHeaderView *headerView;
@property (nonatomic, strong) DOActionMenuView *actionView;
@property (nonatomic, strong) DOJailbreakButton *jailbreakBtn;
@property (nonatomic, strong) NSArray<NSLayoutConstraint *> *jailbreakButtonConstraints;

@property (nonatomic, strong) UIView *alertOverlay;
@property (nonatomic, strong) PopupAlert *alert;
@property (nonatomic, strong) InstallAlert *installAlert;
@property (nonatomic, strong) LoadingAlert *loadingAlert;
@property (nonatomic, strong) CreditsController *creditsTable;

@property (nonatomic, assign) BOOL hideStatusBar;
@property (nonatomic, assign) BOOL hideHomeIndicator;
@property (nonatomic, assign) BOOL restoreRootfsEnabled;
@property (nonatomic, assign) int isJailbroken;

- (BOOL)deviceSupported;
- (BOOL)deviceJailbroken;

- (void)refreshJailbreakButtonTitle;
- (void)handleEnableTweaks:(BOOL)enabled;
- (void)setRestoreRootfsEnabled:(BOOL)enabled;
- (void)changeExploit:(AmethystExploitOption)option;
- (void)saveGeneratorValue:(NSString *)value;
- (void)applyTheme:(NSString *)themeKey;

- (void)userspaceReboot;
- (void)respringDevice;
- (void)refreshIconCache;

@end

extern MainController *mainController;

#endif /* MainController_h */
