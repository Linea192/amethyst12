//
//  DOLogView.m
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Downported to iOS 12: SF Symbol images are loaded on iOS 13+ only and
//  fall back to text glyphs otherwise.
//

#import "DOLogView.h"
#import "DOGlobalAppearance.h"

#define LOG_HEIGHT 40

#pragma mark - DOLoadingIndicator

@implementation DOLoadingIndicator

- (id)init {
    self = [super initWithFrame:CGRectMake(0, 0, 30, 30)];
    if (self) {
        UIImage *image = [UIImage imageNamed:@"Loading"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        imageView.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:imageView];
        [NSLayoutConstraint activateConstraints:@[
            [imageView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
            [imageView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
            [imageView.topAnchor constraintEqualToAnchor:self.topAnchor],
            [imageView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
        ]];

        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        animation.fromValue = @0.0;
        animation.toValue = @(2 * M_PI);
        animation.duration = 1.0;
        animation.repeatCount = INFINITY;
        [imageView.layer addAnimation:animation forKey:@"rotationAnimation"];
    }
    return self;
}

@end

#pragma mark - DODoubleHelixIndicator

@implementation DODoubleHelixIndicator

- (id)init {
    self = [super initWithFrame:CGRectMake(0, 0, 30, 12)];
    if (self) {
        int COUNT = 10;
        for (int i = 0; i < COUNT; i++)
        {
            [self createDotForIndex:i top:YES];
        }
        for (int i = 0; i < COUNT; i++)
        {
            [self createDotForIndex:i top:NO];
        }
    }
    return self;
}

- (void)createDotForIndex:(int)i top:(BOOL)top {
    int HEIGHT = 8;
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(i * (2 + 1), top ? HEIGHT : 0, 2, 2)];
    [view setBackgroundColor:[UIColor whiteColor]];
    [view.layer setCornerRadius:1];
    [view setClipsToBounds:YES];
    [self addSubview:view];

    if (top)
        view.alpha = 0.8;

    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.y"];
    animation.repeatCount = INFINITY;
    animation.duration = 2.3;
    animation.beginTime = CACurrentMediaTime() + (0.1 * i);
    animation.keyTimes = @[@0.0, @0.5, @1.0];
    animation.timingFunctions = @[
        [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut],
        [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut],
        [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]
    ];
    if (top)
        animation.values = @[@0.0, @(HEIGHT * -1), @0.0];
    else
        animation.values = @[@0.0, @(HEIGHT), @0.0];
    [view.layer addAnimation:animation forKey:@"animation"];
}

@end

#pragma mark - DOLyricsLogItemView

@implementation DOLyricsLogItemView

- (id)initWithString:(NSString *)string completedImage:(UIImage *)completedImage failedImage:(UIImage *)failedImage successImage:(UIImage *)successImage {
    if (self = [super init]) {
        self.translatesAutoresizingMaskIntoConstraints = NO;
        self.alpha = 0.9;

        self.label = [[UILabel alloc] init];
        self.label.translatesAutoresizingMaskIntoConstraints = NO;
        self.label.text = string;
        self.label.textColor = [UIColor whiteColor];
        self.label.font = [UIFont systemFontOfSize:20];
        [self addSubview:self.label];

        self.loadingIndicator = [[DOLoadingIndicator alloc] init];
        self.loadingIndicator.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:self.loadingIndicator];

        [NSLayoutConstraint activateConstraints:@[
            [self.loadingIndicator.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
            [self.loadingIndicator.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [self.loadingIndicator.heightAnchor constraintEqualToConstant:30],
            [self.loadingIndicator.widthAnchor constraintEqualToConstant:30],

            [self.label.leadingAnchor constraintEqualToAnchor:self.loadingIndicator.trailingAnchor constant:15],
            [self.label.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
            [self.label.topAnchor constraintEqualToAnchor:self.topAnchor],
            [self.label.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
        ]];
        self.transform = CGAffineTransformMakeTranslation(0, 8);
        self.feedbackGenerator = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        self.alpha = 0;

        self.completedImage = completedImage;
        self.failedImage = failedImage;
        self.successImage = successImage;
    }
    return self;
}

- (void)completeWithImage:(UIImage *)image
{
    if (self.completed) return;
    self.completed = YES;

    UIImageView *imageView = nil;
    if (image != nil) {
        imageView = [[UIImageView alloc] initWithImage:image];
        imageView.translatesAutoresizingMaskIntoConstraints = NO;
        imageView.tintColor = [UIColor whiteColor];
        imageView.alpha = 0;
        [self addSubview:imageView];
        [NSLayoutConstraint activateConstraints:@[
            [imageView.centerYAnchor constraintEqualToAnchor:self.loadingIndicator.centerYAnchor],
            [imageView.centerXAnchor constraintEqualToAnchor:self.loadingIndicator.centerXAnchor],
        ]];
    }

    self.label.font = [UIFont systemFontOfSize:18];

    [UIView animateWithDuration:0.2 animations:^{
        self.alpha = 0.5;
        self.loadingIndicator.alpha = 0;
        imageView.alpha = 1;
        self.transform = CGAffineTransformMakeTranslation(0, 0);
    }];

    [self.feedbackGenerator impactOccurred];
}

- (void)setCompleted {
    [self completeWithImage:self.completedImage];
}

- (void)setFailed {
    [self completeWithImage:self.failedImage];
}

- (void)setSuccess {
    [self completeWithImage:self.successImage];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [self.feedbackGenerator impactOccurredWithIntensity:1];
    });
}

@end

#pragma mark - DOLyricsLogView

@implementation DOLyricsLogView

- (id)init
{
    if (self = [super init]) {
        self.stackView = [[UIStackView alloc] init];
        self.stackView.axis = UILayoutConstraintAxisVertical;
        self.stackView.spacing = 0;
        self.stackView.translatesAutoresizingMaskIntoConstraints = NO;
        self.stackView.alignment = UIStackViewAlignmentLeading;
        [self addSubview:self.stackView];

        [NSLayoutConstraint activateConstraints:@[
            [self.stackView.topAnchor constraintEqualToAnchor:self.bottomAnchor constant:[DOGlobalAppearance isHomeButtonDevice] ? -50 : -80],
            [self.stackView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:25],
            [self.stackView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-25],
        ]];

        if (@available(iOS 13.0, *)) {
            _checkmarkImage = [UIImage systemImageNamed:@"checkmark" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:19 weight:UIImageSymbolWeightRegular]];
            _exclamationMarkImage = [UIImage systemImageNamed:@"exclamationmark.circle" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:19 weight:UIImageSymbolWeightRegular]];
            _unlockedImage = [UIImage systemImageNamed:@"lock.open" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:19 weight:UIImageSymbolWeightRegular]];
        }
    }
    return self;
}

- (void)showLog:(NSString *)log
{
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self showLog:log];
        });
        return;
    }

    [self.stackView.arrangedSubviews makeObjectsPerformSelector:@selector(setCompleted)];

    DOLyricsLogItemView *itemView = [[DOLyricsLogItemView alloc] initWithString:log completedImage:_checkmarkImage failedImage:_exclamationMarkImage successImage:_unlockedImage];
    [self.stackView addArrangedSubview:itemView];

    [NSLayoutConstraint activateConstraints:@[
        [itemView.leadingAnchor constraintEqualToAnchor:self.stackView.leadingAnchor],
        [itemView.trailingAnchor constraintEqualToAnchor:self.stackView.trailingAnchor],
        [itemView.heightAnchor constraintEqualToConstant:LOG_HEIGHT]
    ]];

    CGFloat currentTranslation = self.stackView.transform.ty;
    [UIView animateWithDuration:0.3 animations:^{
        itemView.alpha = 1;
        self.stackView.transform = CGAffineTransformMakeTranslation(0, currentTranslation - LOG_HEIGHT);
    }];
}

- (void)updateLog:(NSString *)log
{
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self updateLog:log];
        });
        return;
    }
    DOLyricsLogItemView *lastItemView = self.stackView.arrangedSubviews.lastObject;
    lastItemView.label.text = log;
}

- (void)didComplete
{
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self didComplete];
        });
        return;
    }

    [self showLog:@"Done"];
    [self.stackView.arrangedSubviews makeObjectsPerformSelector:@selector(setSuccess)];
}

- (void)didFail
{
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self didFail];
        });
        return;
    }

    [self.stackView.arrangedSubviews makeObjectsPerformSelector:@selector(setFailed)];
}

@end
