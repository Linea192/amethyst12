//
//  DONavigationController.m
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Adapted: root view controller is Amethyst's MainController, and the
//  dark-mode override is guarded for iOS 12.
//

#import "DONavigationController.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import "../MainController.h"
#import "DOGlobalAppearance.h"
#import "DOThemeManager.h"

#pragma mark - TessMeteorView

// Falling pixel-art meteors for the "TessXract" theme. A CAEmitterLayer
// (available since iOS 5, so safe on iOS 12/13) spawns pixel streaks near
// the top of the screen that fly down-left at ~30 degrees and fade out,
// sliding behind the translucent action-menu card. Only a handful of
// particles are alive at any time, so it is cheap even on old GPUs.

static UIImage *TessMeteorStreakImage(CGFloat length, CGFloat head)
{
    CGSize size = CGSizeMake(length, head + 4);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();

    // bright square head at the right (front) end
    CGFloat y = (size.height - head) / 2;
    CGContextSetFillColorWithColor(ctx, [UIColor colorWithWhite:1 alpha:0.95].CGColor);
    CGContextFillRect(ctx, CGRectMake(size.width - head, y, head, head));

    // pixel tail: shrinking squares fading toward the left (rear) end
    CGFloat x = size.width - head - 1;
    CGFloat s = head;
    while (x > 0) {
        s = (s > 2) ? s - 1 : 2;
        CGFloat a = 0.8 * (x / size.width) + 0.05;
        CGContextSetFillColorWithColor(ctx, [UIColor colorWithWhite:1 alpha:a].CGColor);
        CGFloat sy = (size.height - s) / 2;
        CGContextFillRect(ctx, CGRectMake(x, sy, s, s));
        x -= s + 1;
    }

    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@interface TessMeteorView : UIView
@end

@implementation TessMeteorView

+ (Class)layerClass
{
    return [CAEmitterLayer class];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = NO;
        self.backgroundColor = [UIColor clearColor];

        // ~150 degrees -> travel direction is down-left
        CGFloat angle = 2.62;

        // Main bright meteors
        CAEmitterCell *main = [CAEmitterCell emitterCell];
        main.contents = (__bridge id)TessMeteorStreakImage(26, 6).CGImage;
        main.birthRate = 0.3;
        main.lifetime = 2.6;
        main.lifetimeRange = 1.0;
        main.velocity = 230;
        main.velocityRange = 70;
        main.emissionLongitude = angle;
        main.emissionRange = 0.1;
        main.scale = 1.0;
        main.scaleRange = 0.4;
        main.alpha = 0.95;
        main.alphaSpeed = -0.35;
        main.rotation = angle; // align the streak with the direction of travel
        main.spin = 0;

        // Small distant meteors
        CAEmitterCell *distant = [CAEmitterCell emitterCell];
        distant.contents = (__bridge id)TessMeteorStreakImage(13, 4).CGImage;
        distant.birthRate = 0.6;
        distant.lifetime = 3.2;
        distant.lifetimeRange = 1.2;
        distant.velocity = 140;
        distant.velocityRange = 50;
        distant.emissionLongitude = angle;
        distant.emissionRange = 0.12;
        distant.scale = 0.8;
        distant.scaleRange = 0.3;
        distant.alpha = 0.55;
        distant.alphaSpeed = -0.16;
        distant.rotation = angle;
        distant.spin = 0;

        CAEmitterLayer *emitter = (CAEmitterLayer *)self.layer;
        emitter.emitterShape = kCAEmitterLayerLine;
        emitter.emitterPosition = CGPointMake(0, -12);
        emitter.emitterSize = CGSizeMake(10, 1); // real values set in layoutSubviews
        emitter.emitterCells = @[main, distant];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CAEmitterLayer *emitter = (CAEmitterLayer *)self.layer;
    // Spawn across the top of the screen, biased toward the right half so
    // the down-left flight path crosses the screen.
    emitter.emitterPosition = CGPointMake(self.bounds.size.width * 0.55, -12);
    emitter.emitterSize = CGSizeMake(self.bounds.size.width * 1.1, 1);
}

@end

@interface DONavigationController ()

@property (nonatomic) UIImageView *backgroundImageView;
@property (nonatomic) TessMeteorView *meteorView;
@property (nonatomic) MainController *mainView;
@property (nonatomic) DOModalBackAction *backAction;

@end

@interface UINavigationController (Private)
- (CGRect)_frameForViewController:(id)arg1;
@end

@implementation DONavigationController

- (void)viewDidLoad
{
    [self setupBackground];
    [super viewDidLoad];
    [self setNavigationBarHidden:YES];
    [self pushViewController:(self.mainView = [[MainController alloc] init]) animated:NO];
    [self setDelegate:self];
    if (@available(iOS 13.0, *)) {
        [self setOverrideUserInterfaceStyle:UIUserInterfaceStyleDark];
    }
}

- (void)setupBackground
{
    DOTheme *theme = [[DOThemeManager sharedInstance] enabledTheme];

    self.view.backgroundColor = [UIColor blackColor];
    self.backgroundImageView = [[UIImageView alloc] init];
    self.backgroundImageView.image = [theme image];
    self.backgroundImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.backgroundImageView.translatesAutoresizingMaskIntoConstraints = NO;
    self.backgroundImageView.userInteractionEnabled = NO;
    self.backgroundImageView.layer.zPosition = -1;

    [self.view insertSubview:self.backgroundImageView atIndex:0];

    [NSLayoutConstraint activateConstraints:@[
        [self.backgroundImageView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.backgroundImageView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.backgroundImageView.topAnchor constraintEqualToAnchor:self.view.topAnchor constant:-100],
        [self.backgroundImageView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor constant:100],
    ]];

    // Falling pixel meteors for the TessXract theme (above the wallpaper,
    // behind all content; they slide behind the translucent menu card).
    if ([[theme key] isEqualToString:@"tessxract"]) {
        TessMeteorView *meteorView = [[TessMeteorView alloc] init];
        meteorView.translatesAutoresizingMaskIntoConstraints = NO;
        meteorView.layer.zPosition = -0.5;
        [self.view insertSubview:meteorView atIndex:1];
        [NSLayoutConstraint activateConstraints:@[
            [meteorView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
            [meteorView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
            [meteorView.topAnchor constraintEqualToAnchor:self.view.topAnchor],
            [meteorView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        ]];
        self.meteorView = meteorView;
    }

    self.backAction = [[DOModalBackAction alloc] initWithAction:^{
        [self popViewControllerAnimated:YES];
    }];
    self.backAction.translatesAutoresizingMaskIntoConstraints = NO;
    self.backAction.hidden = YES;

    [self.view insertSubview:self.backAction atIndex:2];

    [NSLayoutConstraint activateConstraints:@[
        [self.backAction.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.backAction.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.backAction.topAnchor constraintEqualToAnchor:self.view.topAnchor],
        [self.backAction.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
    ]];
}

- (void)setBackgroundDimmed:(BOOL)dimmed
{
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundImageView.alpha = dimmed ? 0.4 : 1;
        self.meteorView.alpha = dimmed ? 0.4 : 1;
    }];
    self.backgroundImageView.userInteractionEnabled = dimmed;
    self.backAction.hidden = !dimmed;
}

#pragma mark - Delegate

- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
           animationControllerForOperation:(UINavigationControllerOperation)operation
                        fromViewController:(UIViewController *)fromVC
                          toViewController:(UIViewController *)toVC {

    if (fromVC.class == MainController.class || toVC.class == MainController.class)
        return [[DOModalTransitionScale alloc] initForwards: operation == UINavigationControllerOperationPush];
    return [[DOModalTransitionPush alloc] initForwards: operation == UINavigationControllerOperationPush];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [self setBackgroundDimmed:![viewController isKindOfClass:[MainController class]]];
    [self.backAction setIgnoreFrame:[self _frameForViewController:viewController]];
}

#pragma mark - Overrides

- (CGRect)_frameForViewController:(id)viewController
{
    CGRect orig = [super _frameForViewController: viewController];
    if ([[viewController class] isEqual: [MainController class]])
        return orig;

    orig.size.width = fmin(orig.size.width - UI_MODAL_PADDING * 2, UI_IPAD_MAX_WIDTH);
    orig.size.height *= [DOGlobalAppearance isSmallDevice] ? 0.8 : 0.7;
    orig.origin.x = (self.view.frame.size.width - orig.size.width) / 2;
    orig.origin.y = (self.view.frame.size.height - orig.size.height) / 2;

    return orig;
}

@end
