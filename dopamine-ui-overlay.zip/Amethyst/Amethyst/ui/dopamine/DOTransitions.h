//
//  DOTransitions.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Contains: DOModalBackAction, DOModalTransitionPush, DOModalTransitionScale.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DOModalBackAction : UIView

@property (nonatomic) void (^action)(void);
@property (nonatomic) CGRect ignoreFrame;

- (id)initWithAction:(void (^)(void))action;

@end

@interface DOModalTransitionPush : NSObject <UIViewControllerAnimatedTransitioning>

- (id)initForwards:(BOOL)forwards;

@end

@interface DOModalTransitionScale : NSObject <UIViewControllerAnimatedTransitioning>

- (id)initForwards:(BOOL)forwards;

@end

NS_ASSUME_NONNULL_END
