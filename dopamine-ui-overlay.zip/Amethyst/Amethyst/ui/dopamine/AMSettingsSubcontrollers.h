//
//  AMSettingsSubcontrollers.h
//  Amethyst (Dopamine UI port)
//
//  Sub-pages of the settings screen, styled like Dopamine's list
//  controllers: AMListItemsController (checkmark picker) and
//  AMGeneratorController (generator value editor).
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMListItemsController : UIViewController

- (instancetype)initWithTitle:(NSString *)title
                        items:(NSArray<NSString *> *)items
                  itemEnabled:(NSArray<NSNumber *> *)itemEnabled
                 selectedIndex:(NSInteger)selectedIndex
                     callback:(void (^)(NSInteger index))callback;

@end

@interface AMGeneratorController : UIViewController

- (instancetype)initWithValue:(NSString *)value
                     callback:(void (^)(NSString *value))callback;

@end

NS_ASSUME_NONNULL_END
