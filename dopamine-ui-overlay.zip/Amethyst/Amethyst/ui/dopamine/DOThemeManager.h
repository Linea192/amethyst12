//
//  DOThemeManager.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) and tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  The enabled theme is stored in Amethyst's own config (amethyst.themeName)
//  instead of Dopamine's preference manager.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "DOTheme.h"

NS_ASSUME_NONNULL_BEGIN

// Posted by -[MainController applyTheme:] right after a new theme is saved.
// DONavigationController crossfades the background image, and the settings
// screens recolor their cards, so the change is visible instantly even
// before the full UI rebuild ([AppDelegate relaunch]) happens.
extern NSString *const AMThemeDidChangeNotification;

@interface DOThemeManager : NSObject

@property (nonatomic, retain) NSArray<DOTheme *> *themes;

// Force every cached theme image to be reloaded from the asset catalog on
// next access (used after a theme change so stale blurred images can never
// be reused).
- (void)invalidateThemeImageCache;

+ (instancetype)sharedInstance;

+ (UIColor *)menuColorWithAlpha:(float)alpha;
+ (UIColor *)windowColorWithAlpha:(float)alpha;

- (NSArray *)getAvailableThemeKeys;
- (NSArray *)getAvailableThemeNames;
- (DOTheme *)getThemeForKey:(NSString *)key;
- (DOTheme *)enabledTheme;

@end

NS_ASSUME_NONNULL_END
