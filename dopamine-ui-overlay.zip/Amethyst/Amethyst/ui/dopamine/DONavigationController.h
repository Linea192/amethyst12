//
//  DONavigationController.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Adapted: root view controller is Amethyst's MainController.
//

#import <UIKit/UIKit.h>
#import "DOTransitions.h"

NS_ASSUME_NONNULL_BEGIN

@interface DONavigationController : UINavigationController <UINavigationControllerDelegate>

@end

NS_ASSUME_NONNULL_END
