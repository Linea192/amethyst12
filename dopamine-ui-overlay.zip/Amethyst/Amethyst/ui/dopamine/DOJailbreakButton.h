//
//  DOJailbreakButton.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Adapted: no package-manager picker (Amethyst handles install options
//  through its own InstallAlert bridge) and no pre-jailbreak mutex.
//

#import <UIKit/UIKit.h>
#import "DOActionMenu.h"
#import "DOLogView.h"

NS_ASSUME_NONNULL_BEGIN

@interface DOJailbreakButton : UIView

@property DOActionMenuButton *button;
@property UIView<DOLogViewProtocol> *logView;

@property (nonatomic, getter=isEnabled) BOOL enabled;
@property (nonatomic) BOOL didExpand;

- (instancetype)initWithItem:(DOActionMenuItem *)item;
- (void)expandButton:(NSArray<NSLayoutConstraint *> *)constraints;
- (void)collapseButton:(NSArray<NSLayoutConstraint *> *)constraints;

@end

NS_ASSUME_NONNULL_END
