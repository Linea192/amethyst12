//
//  DOGlobalAppearance.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) and tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Downported to iOS 12: no UIButtonConfiguration / UIAction APIs.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

#define UI_IPAD_MAX_WIDTH 600
#define UI_MODAL_PADDING 30
#define UI_PADDING 30
//Action Menu
#define UI_INNER_PADDING 20
#define UI_INNER_PADDING_TINY 10
#define UI_INNER_TOP_PADDING 5
#define UI_ACTION_HEIGHT 73
#define UI_ACTION_HEIGHT_HOME_BTN 65
#define UI_ACTION_HEIGHT_TINY 52

#define SE_PHONE_SIZE_CONST 568

@interface DOGlobalAppearance : NSObject

// SF Symbols are iOS 13+; returns nil on iOS 12 (buttons fall back to text-only)
+ (nullable UIImage *)smallIconImageNamed:(NSString *)name;

+ (NSAttributedString *)mainSubtitleString:(NSString *)string;
+ (NSAttributedString *)secondarySubtitleString:(NSString *)string;

+ (BOOL)isHomeButtonDevice;
+ (BOOL)isRTL;
+ (BOOL)isSmallDevice;

@end

NS_ASSUME_NONNULL_END
