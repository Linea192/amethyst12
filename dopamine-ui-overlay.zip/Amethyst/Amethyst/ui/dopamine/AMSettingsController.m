//
//  AMSettingsController.m
//  Amethyst (Dopamine UI port)
//
//  Dopamine-style settings screen for Amethyst.
//  Visual language ported from Dopamine by opa334 / tomt000 (MIT).
//

#import "AMSettingsController.h"
#import "AMSettingsSubcontrollers.h"
#import "DOGlobalAppearance.h"
#import "DOThemeManager.h"
#import "../MainController.h"
#import "../../AppDelegate.h"

#define AM_ROW_HEIGHT 55.0
#define AM_SECTION_SPACING 25.0
#define AM_CARD_RADIUS 14.0

#pragma mark - AMSettingRowView

@interface AMSettingRowView : UIView

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UISwitch *rowSwitch;
@property (nonatomic, strong) UILabel *checkLabel;
@property (nonatomic, strong) UIView *separator;
@property (nonatomic, copy) void (^tapHandler)(void);

- (void)showSeparator:(BOOL)show;
- (void)setRowEnabled:(BOOL)enabled;

@end

@implementation AMSettingRowView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.translatesAutoresizingMaskIntoConstraints = NO;
        self.backgroundColor = [UIColor clearColor];

        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.titleLabel.font = [UIFont systemFontOfSize:17];
        self.titleLabel.textColor = [UIColor whiteColor];
        [self addSubview:self.titleLabel];

        self.detailLabel = [[UILabel alloc] init];
        self.detailLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.detailLabel.font = [UIFont systemFontOfSize:17];
        self.detailLabel.textColor = [UIColor colorWithWhite:1 alpha:0.6];
        [self.detailLabel setTextAlignment:NSTextAlignmentRight];
        [self addSubview:self.detailLabel];

        self.separator = [[UIView alloc] init];
        self.separator.translatesAutoresizingMaskIntoConstraints = NO;
        self.separator.backgroundColor = [UIColor colorWithWhite:0.6 alpha:0.3];
        self.separator.layer.cornerRadius = 0.5;
        self.separator.layer.masksToBounds = YES;
        self.separator.hidden = YES;
        [self addSubview:self.separator];

        [NSLayoutConstraint activateConstraints:@[
            [self.titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:20],
            [self.titleLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [self.detailLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-20],
            [self.detailLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [self.detailLabel.leadingAnchor constraintGreaterThanOrEqualToAnchor:self.titleLabel.trailingAnchor constant:12],
            [self.separator.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
            [self.separator.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
            [self.separator.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
            [self.separator.heightAnchor constraintEqualToConstant:1],
        ]];

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rowTapped)];
        [self addGestureRecognizer:tap];
        self.userInteractionEnabled = YES;
    }
    return self;
}

- (void)attachSwitchWithTarget:(id)target selector:(SEL)selector initialState:(BOOL)state
{
    if (self.rowSwitch != nil) return;
    self.rowSwitch = [[UISwitch alloc] init];
    self.rowSwitch.translatesAutoresizingMaskIntoConstraints = NO;
    self.rowSwitch.on = state;
    [self.rowSwitch addTarget:target action:selector forControlEvents:UIControlEventValueChanged];
    [self addSubview:self.rowSwitch];
    [NSLayoutConstraint activateConstraints:@[
        [self.rowSwitch.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-20],
        [self.rowSwitch.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
    ]];
}

- (void)attachCheckmark:(BOOL)checked
{
    if (self.checkLabel != nil) return;
    self.checkLabel = [[UILabel alloc] init];
    self.checkLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.checkLabel.text = checked ? @"\u2713" : nil;
    self.checkLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightMedium];
    self.checkLabel.textColor = [UIColor whiteColor];
    [self addSubview:self.checkLabel];
    [NSLayoutConstraint activateConstraints:@[
        [self.checkLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-20],
        [self.checkLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
    ]];
}

- (void)showSeparator:(BOOL)show
{
    self.separator.hidden = !show;
}

- (void)setRowEnabled:(BOOL)enabled
{
    self.userInteractionEnabled = enabled;
    self.alpha = enabled ? 1.0 : 0.4;
}

- (void)rowTapped
{
    if (self.tapHandler != nil) {
        self.tapHandler();
    }
}

@end

#pragma mark - AMSettingsController

@interface AMSettingsController ()

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIStackView *contentStack;

@end

@implementation AMSettingsController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.35];

    [self setupBackButton];
    [self setupTitle];
    [self setupContent];
}

- (void)setupBackButton
{
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.translatesAutoresizingMaskIntoConstraints = NO;
    [backButton setTitle:@"Amethyst" forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor colorWithWhite:1 alpha:0.8] forState:UIControlStateNormal];
    backButton.titleLabel.font = [UIFont systemFontOfSize:17];

    UIImage *chevron = [DOGlobalAppearance smallIconImageNamed:@"chevron.left"];
    if (chevron != nil) {
        [backButton setImage:chevron forState:UIControlStateNormal];
        backButton.titleEdgeInsets = UIEdgeInsetsMake(0, 8, 0, -8);
        backButton.tintColor = [UIColor colorWithWhite:1 alpha:0.8];
    } else {
        [backButton setTitle:@"\u2039 Amethyst" forState:UIControlStateNormal];
    }

    [backButton addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:backButton];
    [NSLayoutConstraint activateConstraints:@[
        [backButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:20],
        [backButton.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:15],
        [backButton.heightAnchor constraintEqualToConstant:30],
    ]];
}

- (void)goBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setupTitle
{
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = @"Settings";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:30 weight:UIFontWeightSemibold];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [titleLabel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:12],
    ]];
}

- (void)setupContent
{
    self.scrollView = [[UIScrollView alloc] init];
    self.scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    self.scrollView.alwaysBounceVertical = YES;
    [self.view addSubview:self.scrollView];

    self.contentStack = [[UIStackView alloc] init];
    self.contentStack.axis = UILayoutConstraintAxisVertical;
    self.contentStack.spacing = AM_SECTION_SPACING;
    self.contentStack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.scrollView addSubview:self.contentStack];

    [NSLayoutConstraint activateConstraints:@[
        [self.scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:60],
        [self.scrollView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
        [self.scrollView.widthAnchor constraintEqualToAnchor:self.view.widthAnchor],

        [self.contentStack.leadingAnchor constraintEqualToAnchor:self.scrollView.leadingAnchor constant:UI_PADDING],
        [self.contentStack.trailingAnchor constraintEqualToAnchor:self.scrollView.trailingAnchor constant:-UI_PADDING],
        [self.contentStack.topAnchor constraintEqualToAnchor:self.scrollView.topAnchor constant:10],
        [self.contentStack.bottomAnchor constraintEqualToAnchor:self.scrollView.bottomAnchor constant:-25],
        [self.contentStack.widthAnchor constraintEqualToAnchor:self.scrollView.widthAnchor constant:-UI_PADDING * 2],
    ]];

    BOOL jailbroken = [mainController deviceJailbroken];

    // Jailbreak options
    [self addSectionHeader:@"JAILBREAK OPTIONS"];

    NSMutableArray<UIView *> *jailbreakRows = [[NSMutableArray alloc] init];
    [jailbreakRows addObject:[self switchRowWithTitle:@"Enable Tweaks"
                                        switchState:amethyst.enableTweaks
                                            target:self
                                            selector:@selector(handleEnableTweaks:)]];
    if (!jailbroken) {
        [jailbreakRows addObject:[self switchRowWithTitle:@"Restore RootFS"
                                              switchState:mainController.restoreRootfsEnabled
                                                  target:self
                                                  selector:@selector(handleRestoreRootfs:)]];
    }
    [self addCardWithRows:jailbreakRows];

    if (!jailbroken) {
        // Advanced
        [self addSectionHeader:@"ADVANCED"];

        NSMutableArray<UIView *> *advancedRows = [[NSMutableArray alloc] init];
        [advancedRows addObject:[self detailRowWithTitle:@"Exploit"
                                                  detail:[amethyst exploitString]
                                              tapHandler:^{
            [self pushExploitPicker];
        }]];
        [advancedRows addObject:[self detailRowWithTitle:@"Generator"
                                                  detail:amethyst.generator
                                              tapHandler:^{
            [self pushGeneratorEditor];
        }]];
        [self addCardWithRows:advancedRows];
    }

    // Appearance
    [self addSectionHeader:@"APPEARANCE"];

    NSMutableArray<UIView *> *appearanceRows = [[NSMutableArray alloc] init];
    [appearanceRows addObject:[self detailRowWithTitle:@"Theme"
                                               detail:[[[DOThemeManager sharedInstance] enabledTheme] name]
                                           tapHandler:^{
        [self pushThemePicker];
    }]];
    [self addCardWithRows:appearanceRows];

    if (jailbroken) {
        // Utilities
        [self addSectionHeader:@"UTILITIES"];

        NSMutableArray<UIView *> *utilityRows = [[NSMutableArray alloc] init];
        [utilityRows addObject:[self detailRowWithTitle:@"Reboot Userspace"
                                                 detail:@""
                                             tapHandler:^{
            [mainController userspaceReboot];
        }]];
        [utilityRows addObject:[self detailRowWithTitle:@"Restart SpringBoard"
                                                 detail:@""
                                             tapHandler:^{
            [mainController respringDevice];
        }]];
        [utilityRows addObject:[self detailRowWithTitle:@"Refresh Icon Cache"
                                                 detail:@""
                                             tapHandler:^{
            [mainController refreshIconCache];
        }]];
        [self addCardWithRows:utilityRows];
    }

    // Version footer
    UIView *footer = [[UIView alloc] init];
    footer.translatesAutoresizingMaskIntoConstraints = NO;
    [footer.heightAnchor constraintEqualToConstant:30].active = YES;

    UILabel *versionLabel = [[UILabel alloc] init];
    versionLabel.translatesAutoresizingMaskIntoConstraints = NO;
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    versionLabel.text = [NSString stringWithFormat:@"version %@", version ?: @"?"];
    versionLabel.font = [UIFont systemFontOfSize:12];
    versionLabel.textColor = [UIColor colorWithWhite:1 alpha:0.6];
    versionLabel.textAlignment = NSTextAlignmentCenter;
    [footer addSubview:versionLabel];
    [NSLayoutConstraint activateConstraints:@[
        [versionLabel.centerXAnchor constraintEqualToAnchor:footer.centerXAnchor],
        [versionLabel.centerYAnchor constraintEqualToAnchor:footer.centerYAnchor],
    ]];
    [self.contentStack addArrangedSubview:footer];
}

#pragma mark - Card building

- (void)addSectionHeader:(NSString *)text
{
    UIView *header = [[UIView alloc] init];
    header.translatesAutoresizingMaskIntoConstraints = NO;
    [header.heightAnchor constraintEqualToConstant:25].active = YES;

    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
    label.textColor = [UIColor colorWithWhite:1 alpha:0.6];
    [header addSubview:label];
    [NSLayoutConstraint activateConstraints:@[
        [label.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:10],
        [label.centerYAnchor constraintEqualToAnchor:header.centerYAnchor],
    ]];

    [self.contentStack addArrangedSubview:header];
}

- (void)addCardWithRows:(NSArray<AMSettingRowView *> *)rows
{
    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
    card.layer.cornerRadius = AM_CARD_RADIUS;
    card.layer.masksToBounds = YES;
    if (@available(iOS 13.0, *)) {
        card.layer.cornerCurve = kCACornerCurveContinuous;
    }
    [self.contentStack addArrangedSubview:card];

    AMSettingRowView *previous = nil;
    for (AMSettingRowView *row in rows) {
        [card addSubview:row];
        [NSLayoutConstraint activateConstraints:@[
            [row.leadingAnchor constraintEqualToAnchor:card.leadingAnchor],
            [row.trailingAnchor constraintEqualToAnchor:card.trailingAnchor],
            [row.heightAnchor constraintEqualToConstant:AM_ROW_HEIGHT],
            [row.topAnchor constraintEqualToAnchor:(previous != nil ? previous.bottomAnchor : card.topAnchor)],
        ]];
        previous = row;
    }
    [NSLayoutConstraint activateConstraints:@[
        [rows.lastObject.bottomAnchor constraintEqualToAnchor:card.bottomAnchor],
    ]];

    for (NSUInteger i = 0; i < rows.count; i++) {
        [rows[i] showSeparator:(i != rows.count - 1)];
    }
}

- (AMSettingRowView *)switchRowWithTitle:(NSString *)title switchState:(BOOL)state target:(id)target selector:(SEL)selector
{
    AMSettingRowView *row = [[AMSettingRowView alloc] init];
    row.titleLabel.text = title;
    [row attachSwitchWithTarget:target selector:selector initialState:state];
    return row;
}

- (AMSettingRowView *)detailRowWithTitle:(NSString *)title detail:(NSString *)detail tapHandler:(void (^)(void))tapHandler
{
    AMSettingRowView *row = [[AMSettingRowView alloc] init];
    row.titleLabel.text = title;
    if (detail.length > 0) {
        row.detailLabel.text = detail;
    }
    row.tapHandler = tapHandler;
    return row;
}

#pragma mark - Actions

- (void)handleEnableTweaks:(UISwitch *)_switch
{
    [mainController handleEnableTweaks:_switch.on];
}

- (void)handleRestoreRootfs:(UISwitch *)_switch
{
    [mainController setRestoreRootfsEnabled:_switch.on];
}

#pragma mark - Push subcontrollers

- (void)pushExploitPicker
{
    NSMutableArray *names = [[NSMutableArray alloc] init];
    NSMutableArray *enabled = [[NSMutableArray alloc] init];
    [names addObject:@"Hemlock"];
    [enabled addObject:@YES];
    [names addObject:@"Trigon"];
    [enabled addObject:@(amethyst.trigonSupported ? YES : NO)];

    AMListItemsController *picker = [[AMListItemsController alloc] initWithTitle:@"Exploit"
                                                                           items:names
                                                                   itemEnabled:enabled
                                                                    selectedIndex:amethyst.exploit
                                                                         callback:^(NSInteger index) {
        AmethystExploitOption option = (index == 0) ? Exploit_Hemlock : Exploit_Trigon;
        [mainController changeExploit:option];
    }];
    [self.navigationController pushViewController:picker animated:YES];
}

- (void)pushGeneratorEditor
{
    AMGeneratorController *editor = [[AMGeneratorController alloc] initWithValue:amethyst.generator
                                                                         callback:^(NSString *value) {
        [mainController saveGeneratorValue:value];
    }];
    [self.navigationController pushViewController:editor animated:YES];
}

- (void)pushThemePicker
{
    DOThemeManager *manager = [DOThemeManager sharedInstance];
    NSArray *names = [manager getAvailableThemeNames];
    NSArray *keys = [manager getAvailableThemeKeys];

    NSMutableArray *enabled = [[NSMutableArray alloc] init];
    for (NSUInteger i = 0; i < names.count; i++) [enabled addObject:@YES];

    NSInteger selected = [keys indexOfObject:[[manager enabledTheme] key]];
    if (selected == NSNotFound) selected = 0;

    AMListItemsController *picker = [[AMListItemsController alloc] initWithTitle:@"Theme"
                                                                           items:[names mutableCopy]
                                                                   itemEnabled:enabled
                                                                    selectedIndex:selected
                                                                         callback:^(NSInteger index) {
        [mainController applyTheme:keys[index]];
    }];
    [self.navigationController pushViewController:picker animated:YES];
}

@end
