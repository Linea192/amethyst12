//
//  AMSettingsSubcontrollers.m
//  Amethyst (Dopamine UI port)
//
//  AMListItemsController and AMGeneratorController, styled after
//  Dopamine's list controllers (by opa334 / tomt000, MIT).
//

#import "AMSettingsSubcontrollers.h"
#import "DOGlobalAppearance.h"
#import "DOThemeManager.h"
#import <ctype.h>

#define AM_SUB_ROW_HEIGHT 55.0
#define AM_SUB_CARD_RADIUS 14.0

static UIButton *AMMakeBackButton(id target, SEL selector, NSString *title)
{
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.translatesAutoresizingMaskIntoConstraints = NO;
    [backButton setTitle:title forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor colorWithWhite:1 alpha:0.8] forState:UIControlStateNormal];
    backButton.titleLabel.font = [UIFont systemFontOfSize:17];

    UIImage *chevron = [DOGlobalAppearance smallIconImageNamed:@"chevron.left"];
    if (chevron != nil) {
        [backButton setImage:chevron forState:UIControlStateNormal];
        backButton.titleEdgeInsets = UIEdgeInsetsMake(0, 8, 0, -8);
        backButton.tintColor = [UIColor colorWithWhite:1 alpha:0.8];
    } else {
        [backButton setTitle:[NSString stringWithFormat:@"\u2039 %@", title] forState:UIControlStateNormal];
    }

    [backButton addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    return backButton;
}

static UILabel *AMMakeTitleLabel(NSString *text)
{
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = text;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:30 weight:UIFontWeightSemibold];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    return titleLabel;
}

static void AMApplyModalBackground(UIView *view)
{
    view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.35];
}

#pragma mark - AMListItemsController

@interface AMListItemsController ()

@property (nonatomic, copy) NSString *titleText;
@property (nonatomic, copy) NSArray<NSString *> *items;
@property (nonatomic, copy) NSArray<NSNumber *> *itemEnabled;
@property (nonatomic, assign) NSInteger selectedIndex;
@property (nonatomic, copy) void (^callback)(NSInteger);
@property (nonatomic, strong) UIView *card;

@end

@implementation AMListItemsController

- (instancetype)initWithTitle:(NSString *)title
                        items:(NSArray<NSString *> *)items
                  itemEnabled:(NSArray<NSNumber *> *)itemEnabled
                 selectedIndex:(NSInteger)selectedIndex
                     callback:(void (^)(NSInteger))callback
{
    self = [super init];
    if (self) {
        _titleText = [title copy];
        _items = [items copy];
        _itemEnabled = [itemEnabled copy];
        _selectedIndex = selectedIndex;
        _callback = callback;
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    AMApplyModalBackground(self.view);

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(themeDidChange:)
                                                 name:AMThemeDidChangeNotification
                                               object:nil];

    UIButton *backButton = AMMakeBackButton(self, @selector(goBack), @"Settings");
    [self.view addSubview:backButton];
    [NSLayoutConstraint activateConstraints:@[
        [backButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:20],
        [backButton.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:15],
        [backButton.heightAnchor constraintEqualToConstant:30],
    ]];

    UILabel *titleLabel = AMMakeTitleLabel(self.titleText);
    [self.view addSubview:titleLabel];
    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [titleLabel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:52],
    ]];

    // The list lives inside a scroll view: this screen is presented as a
    // centered modal card (~70% of the screen height), and with many items
    // (e.g. the 9 themes) the card would otherwise extend past the view's
    // bounds - rows out there render (clipsToBounds is off) but can never
    // receive touches, which made the last few themes impossible to select
    // on shorter devices. Scrolling keeps every row tappable.
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    scrollView.alwaysBounceVertical = NO;
    [self.view addSubview:scrollView];

    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
    card.layer.cornerRadius = AM_SUB_CARD_RADIUS;
    card.layer.masksToBounds = YES;
    if (@available(iOS 13.0, *)) {
        card.layer.cornerCurve = kCACornerCurveContinuous;
    }
    self.card = card;
    [scrollView addSubview:card];

    UIView *previous = nil;
    for (NSUInteger i = 0; i < self.items.count; i++) {
        UIView *row = [self rowForIndex:i];
        [card addSubview:row];
        [NSLayoutConstraint activateConstraints:@[
            [row.leadingAnchor constraintEqualToAnchor:card.leadingAnchor],
            [row.trailingAnchor constraintEqualToAnchor:card.trailingAnchor],
            [row.heightAnchor constraintEqualToConstant:AM_SUB_ROW_HEIGHT],
            [row.topAnchor constraintEqualToAnchor:(previous != nil ? previous.bottomAnchor : card.topAnchor)],
        ]];
        previous = row;
    }
    [NSLayoutConstraint activateConstraints:@[
        [previous.bottomAnchor constraintEqualToAnchor:card.bottomAnchor],

        [scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:104],
        [scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor constant:-15],

        [card.leadingAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.leadingAnchor constant:UI_PADDING],
        [card.trailingAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.trailingAnchor constant:-UI_PADDING],
        [card.topAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.topAnchor],
        [card.bottomAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.bottomAnchor constant:-25],
        [scrollView.contentLayoutGuide.widthAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.widthAnchor],
    ]];
}

- (void)themeDidChange:(NSNotification *)notification
{
    // Live recolor so the card matches the new theme immediately.
    self.card.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
}

- (UIView *)rowForIndex:(NSUInteger)index
{
    NSString *title = self.items[index];
    BOOL enabled = self.itemEnabled[index].boolValue;
    BOOL checked = (index == (NSUInteger)self.selectedIndex);

    UIView *row = [[UIView alloc] init];
    row.translatesAutoresizingMaskIntoConstraints = NO;
    row.userInteractionEnabled = enabled;

    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = title;
    label.font = [UIFont systemFontOfSize:17];
    label.textColor = [UIColor whiteColor];
    [row addSubview:label];

    UILabel *check = [[UILabel alloc] init];
    check.translatesAutoresizingMaskIntoConstraints = NO;
    check.text = checked ? @"\u2713" : nil;
    check.font = [UIFont systemFontOfSize:17 weight:UIFontWeightMedium];
    check.textColor = [UIColor whiteColor];
    [row addSubview:check];

    if (index != self.items.count - 1) {
        UIView *separator = [[UIView alloc] init];
        separator.translatesAutoresizingMaskIntoConstraints = NO;
        separator.backgroundColor = [UIColor colorWithWhite:0.6 alpha:0.3];
        separator.layer.cornerRadius = 0.5;
        separator.layer.masksToBounds = YES;
        [row addSubview:separator];
        [NSLayoutConstraint activateConstraints:@[
            [separator.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:10],
            [separator.trailingAnchor constraintEqualToAnchor:row.trailingAnchor constant:-10],
            [separator.bottomAnchor constraintEqualToAnchor:row.bottomAnchor],
            [separator.heightAnchor constraintEqualToConstant:1],
        ]];
    }

    [NSLayoutConstraint activateConstraints:@[
        [label.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:20],
        [label.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
        [check.trailingAnchor constraintEqualToAnchor:row.trailingAnchor constant:-20],
        [check.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
    ]];

    if (!enabled) {
        row.alpha = 0.4;
    } else {
        row.tag = index;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rowTapped:)];
        [row addGestureRecognizer:tap];
    }

    return row;
}

- (void)rowTapped:(UITapGestureRecognizer *)recognizer
{
    NSInteger index = recognizer.view.tag;
    if (self.callback != nil) {
        self.callback(index);
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)goBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end

#pragma mark - AMGeneratorController

@interface AMGeneratorController ()

@property (nonatomic, copy) NSString *value;
@property (nonatomic, copy) void (^callback)(NSString *);
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UIButton *saveButton;

@end

@implementation AMGeneratorController

- (instancetype)initWithValue:(NSString *)value callback:(void (^)(NSString *))callback
{
    self = [super init];
    if (self) {
        _value = [value copy];
        _callback = callback;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    AMApplyModalBackground(self.view);

    UIButton *backButton = AMMakeBackButton(self, @selector(goBack), @"Settings");
    [self.view addSubview:backButton];
    [NSLayoutConstraint activateConstraints:@[
        [backButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:20],
        [backButton.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:15],
        [backButton.heightAnchor constraintEqualToConstant:30],
    ]];

    UILabel *titleLabel = AMMakeTitleLabel(@"Generator");
    [self.view addSubview:titleLabel];
    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [titleLabel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:52],
    ]];

    // Card with text field + save
    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
    card.layer.cornerRadius = AM_SUB_CARD_RADIUS;
    card.layer.masksToBounds = YES;
    if (@available(iOS 13.0, *)) {
        card.layer.cornerCurve = kCACornerCurveContinuous;
    }
    [self.view addSubview:card];

    self.textField = [[UITextField alloc] init];
    self.textField.translatesAutoresizingMaskIntoConstraints = NO;
    self.textField.text = self.value;
    self.textField.textColor = [UIColor whiteColor];
    self.textField.font = [UIFont fontWithName:@"Menlo-Regular" size:16];
    self.textField.keyboardType = UIKeyboardTypeASCIICapable;
    self.textField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.textField.textAlignment = NSTextAlignmentCenter;
    self.textField.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.25];
    self.textField.layer.cornerRadius = 10;
    self.textField.layer.masksToBounds = YES;
    [self.textField addTarget:self action:@selector(textFieldChanged:) forControlEvents:UIControlEventEditingChanged];
    [card addSubview:self.textField];

    self.saveButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.saveButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.saveButton setTitle:@"Save" forState:UIControlStateNormal];
    [self.saveButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.saveButton.titleLabel.font = [UIFont systemFontOfSize:17];
    [self.saveButton addTarget:self action:@selector(save) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:self.saveButton];

    UIView *separator = [[UIView alloc] init];
    separator.translatesAutoresizingMaskIntoConstraints = NO;
    separator.backgroundColor = [UIColor colorWithWhite:0.6 alpha:0.3];
    separator.layer.cornerRadius = 0.5;
    separator.layer.masksToBounds = YES;
    [card addSubview:separator];

    [NSLayoutConstraint activateConstraints:@[
        [card.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:UI_PADDING],
        [card.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-UI_PADDING],
        [card.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:104],

        [self.textField.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:20],
        [self.textField.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-20],
        [self.textField.topAnchor constraintEqualToAnchor:card.topAnchor constant:20],
        [self.textField.heightAnchor constraintEqualToConstant:44],

        [separator.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:10],
        [separator.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-10],
        [separator.topAnchor constraintEqualToAnchor:self.textField.bottomAnchor constant:15],
        [separator.heightAnchor constraintEqualToConstant:1],

        [self.saveButton.leadingAnchor constraintEqualToAnchor:card.leadingAnchor],
        [self.saveButton.trailingAnchor constraintEqualToAnchor:card.trailingAnchor],
        [self.saveButton.topAnchor constraintEqualToAnchor:separator.bottomAnchor],
        [self.saveButton.heightAnchor constraintEqualToConstant:AM_SUB_ROW_HEIGHT],
        [self.saveButton.bottomAnchor constraintEqualToAnchor:card.bottomAnchor],
    ]];

    [self validateTextField];
}

// Same validation logic as original Amethyst (monitorGeneratorText:)
- (void)validateTextField
{
    NSString *text = self.textField.text;
    BOOL valid = NO;

    if (text.length == 18) {
        const char *chars = [text UTF8String];
        if (chars[0] == '0' && chars[1] == 'x') {
            valid = YES;
            for (int i = 2; i < 18; i++) {
                if (!isxdigit(chars[i])) {
                    valid = NO;
                    break;
                }
            }
        }
    }

    self.saveButton.enabled = valid;
    [self.saveButton setTitleColor:(valid ? [UIColor whiteColor] : [[UIColor whiteColor] colorWithAlphaComponent:0.4]) forState:UIControlStateNormal];
}

- (void)textFieldChanged:(UITextField *)textField
{
    if (textField.text.length > 18) {
        [textField deleteBackward];
    }
    [self validateTextField];
}

- (void)save
{
    if (!self.saveButton.enabled) return;
    if (self.callback != nil) {
        self.callback(self.textField.text);
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)goBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
