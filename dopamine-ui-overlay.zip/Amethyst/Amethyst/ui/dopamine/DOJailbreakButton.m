//
//  DOJailbreakButton.m
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Adapted: no package-manager picker, no mutex, added collapseButton:
//  so Amethyst can restore the main screen after a failed jailbreak.
//

#import "DOJailbreakButton.h"
#import "DOGlobalAppearance.h"
#import "DOThemeManager.h"

@interface DOJailbreakButton ()

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) DODoubleHelixIndicator *indicator;
@property (nonatomic, strong) NSArray<NSLayoutConstraint *> *expandedConstraints;
@property (nonatomic, strong) NSArray<NSLayoutConstraint *> *normalConstraints;

@end

@implementation DOJailbreakButton

- (instancetype)initWithItem:(DOActionMenuItem *)item
{
    if (self = [super init])
    {
        self.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
        self.layer.cornerRadius = 14;
        self.layer.masksToBounds = YES;
        if (@available(iOS 13.0, *)) {
            self.layer.cornerCurve = kCACornerCurveContinuous;
        }
        self.translatesAutoresizingMaskIntoConstraints = NO;

        self.button = [DOActionMenuButton buttonWithItem:item chevron:NO];
        [self.button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
        self.button.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:self.button];
        [NSLayoutConstraint activateConstraints:@[
            [self.button.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
            [self.button.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
            [self.button.topAnchor constraintEqualToAnchor:self.topAnchor],
            [self.button.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
        ]];
    }
    return self;
}

- (void)expandButton:(NSArray<NSLayoutConstraint *> *)constraints
{
    if (self.didExpand)
        return;

    self.didExpand = TRUE;
    self.normalConstraints = constraints;

    UIWindow *window = [[UIApplication sharedApplication] keyWindow];

    float topPadding = (window.frame.size.height * (1 - 0.74));
    topPadding += 35;

    [self setupLog:topPadding];

    [NSLayoutConstraint deactivateConstraints:constraints];

    self.expandedConstraints = @[
        [self.leadingAnchor constraintEqualToAnchor:window.leadingAnchor],
        [self.trailingAnchor constraintEqualToAnchor:window.trailingAnchor],
        [self.topAnchor constraintEqualToAnchor:window.topAnchor constant:topPadding],
        [self.bottomAnchor constraintEqualToAnchor:window.bottomAnchor constant:100] // slightly out of the screen to hide corners on i8
    ];
    [NSLayoutConstraint activateConstraints:self.expandedConstraints];

    [self.button setUserInteractionEnabled:NO];

    [UIView animateWithDuration:0.2 animations:^{ [self.button setAlpha:0.0]; }];
    [UIView animateWithDuration:0.75 delay:0.0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [window layoutIfNeeded];
        [self.button setAlpha:0.0];
    } completion:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.25 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [self setupTitle];
    });
}

- (void)collapseButton:(NSArray<NSLayoutConstraint *> *)constraints
{
    if (!self.didExpand)
        return;

    self.didExpand = FALSE;

    if (self.logView != nil) {
        [self.logView removeFromSuperview];
        self.logView = nil;
    }
    if (self.titleLabel != nil) {
        [self.titleLabel removeFromSuperview];
        self.titleLabel = nil;
    }
    if (self.indicator != nil) {
        [self.indicator removeFromSuperview];
        self.indicator = nil;
    }

    if (self.expandedConstraints != nil) {
        [NSLayoutConstraint deactivateConstraints:self.expandedConstraints];
        self.expandedConstraints = nil;
    }

    if (constraints != nil) {
        [NSLayoutConstraint activateConstraints:constraints];
    }

    self.button.userInteractionEnabled = YES;

    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    [UIView animateWithDuration:0.75 delay:0.0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [window layoutIfNeeded];
        [self.button setAlpha:1.0];
    } completion:nil];
}

- (void)setupLog:(float)topPadding
{
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];

    self.logView = [[DOLyricsLogView alloc] init];
    self.logView.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:self.logView];

    [NSLayoutConstraint activateConstraints:@[
        [self.logView.leadingAnchor constraintEqualToAnchor:window.leadingAnchor],
        [self.logView.trailingAnchor constraintEqualToAnchor:window.trailingAnchor],
        [self.logView.topAnchor constraintEqualToAnchor:window.topAnchor constant:topPadding],
        [self.logView.bottomAnchor constraintEqualToAnchor:window.bottomAnchor constant:0]
    ]];

    [window layoutIfNeeded];
}

- (void)setupTitle
{
    if (self.titleLabel != nil) return;

    UIWindow *window = [[UIApplication sharedApplication] keyWindow];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = @"Jailbreaking";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightRegular];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.alpha = 0.0;
    [self addSubview:titleLabel];
    self.titleLabel = titleLabel;

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.centerXAnchor constraintEqualToAnchor:window.centerXAnchor constant:20],
        [titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:20],
    ]];

    [UIView animateWithDuration:0.2 animations:^{
        titleLabel.alpha = 1.0;
    }];

    DODoubleHelixIndicator *indicator = [[DODoubleHelixIndicator alloc] init];
    [self addSubview:indicator];
    self.indicator = indicator;
    indicator.translatesAutoresizingMaskIntoConstraints = NO;

    [NSLayoutConstraint activateConstraints:@[
        [indicator.trailingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor constant:-10],
        [indicator.centerYAnchor constraintEqualToAnchor:titleLabel.centerYAnchor],
        [indicator.widthAnchor constraintEqualToConstant:30],
        [indicator.heightAnchor constraintEqualToConstant:12],
    ]];
}

- (void)setEnabled:(BOOL)enabled
{
    self.button.userInteractionEnabled = enabled;
    if (enabled) {
        self.alpha = 1.0;
    } else {
        self.alpha = 0.7;
    }
}

- (BOOL)isEnabled
{
    return self.button.userInteractionEnabled;
}

@end
