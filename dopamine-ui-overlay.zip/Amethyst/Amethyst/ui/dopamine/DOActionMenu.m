//
//  DOActionMenu.m
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) and tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Downported to iOS 12: classic UIButton APIs instead of
//  UIButtonConfiguration / UIAction.
//

#import "DOActionMenu.h"

#pragma mark - DOActionMenuItem

@implementation DOActionMenuItem

+ (instancetype)itemWithTitle:(NSString *)title image:(NSString *)imageName identifier:(NSString *)identifier handler:(void (^)(void))handler
{
    DOActionMenuItem *item = [[DOActionMenuItem alloc] init];
    item.title = title;
    item.imageName = imageName;
    item.identifier = identifier;
    item.handler = handler;
    return item;
}

@end

#pragma mark - DOActionMenuButton

@interface DOActionMenuButton ()
{
    UIView *_separator;
}

@property (nonatomic) UIImpactFeedbackGenerator *feedbackGenerator;

@end

@implementation DOActionMenuButton

+ (DOActionMenuButton *)buttonWithItem:(DOActionMenuItem *)item chevron:(BOOL)chevron
{
    DOActionMenuButton *button = [DOActionMenuButton buttonWithType:UIButtonTypeCustom];
    button.item = item;

    [button setTitle:item.title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button setTitleColor:[[UIColor whiteColor] colorWithAlphaComponent:0.75] forState:UIControlStateHighlighted];
    [button.titleLabel setAdjustsFontSizeToFitWidth:YES];
    button.titleLabel.font = [UIFont systemFontOfSize:17];

    UIImage *icon = nil;
    if (item.imageName != nil) {
        icon = [DOGlobalAppearance smallIconImageNamed:item.imageName];
    }
    if (icon != nil) {
        [button setImage:icon forState:UIControlStateNormal];
        // 10pt padding between icon and title (Dopamine's imagePadding)
        button.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10);
    }
    if (chevron) {
        UIImageView *chevronView = nil;
        if (@available(iOS 13.0, *)) {
            UIImage *chevronImage = [UIImage systemImageNamed:@"chevron.right"];
            if (chevronImage != nil) {
                chevronImage = [chevronImage imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:16 weight:UIImageSymbolWeightRegular]];
                chevronView = [[UIImageView alloc] initWithImage:chevronImage];
            }
        }
        if (chevronView != nil) {
            chevronView.translatesAutoresizingMaskIntoConstraints = NO;
            chevronView.tintColor = [UIColor colorWithWhite:1 alpha:0.6];
            [button addSubview:chevronView];
            [NSLayoutConstraint activateConstraints:@[
                [chevronView.trailingAnchor constraintEqualToAnchor:button.trailingAnchor constant:-10],
                [chevronView.centerYAnchor constraintEqualToAnchor:button.centerYAnchor],
            ]];
        }
    }

    [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    if ([DOGlobalAppearance isRTL])
        [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];

    button.feedbackGenerator = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [button addTarget:button action:@selector(buttonPressed) forControlEvents:UIControlEventTouchUpInside];

    return button;
}

- (void)buttonPressed
{
    [self.feedbackGenerator impactOccurred];
    if (self.item.handler != nil) {
        self.item.handler();
    }
}

- (void)setBottomSeparator:(BOOL)bottomSeparator
{
    _bottomSeparator = bottomSeparator;
    if (_separator)
        [_separator removeFromSuperview];
    if (bottomSeparator)
    {
        _separator = [[UIView alloc] init];
        _separator.backgroundColor = [UIColor colorWithWhite:0.6 alpha:0.3];
        _separator.translatesAutoresizingMaskIntoConstraints = NO;
        _separator.layer.cornerRadius = 0.5;
        _separator.layer.masksToBounds = YES;
        [self addSubview:_separator];
        [NSLayoutConstraint activateConstraints:@[
            [_separator.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
            [_separator.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
            [_separator.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
            [_separator.heightAnchor constraintEqualToConstant:1],
        ]];
    }
}

@end

#pragma mark - DOActionMenuView

@implementation DOActionMenuView

- (instancetype)initWithItems:(NSArray<DOActionMenuItem *> *)items delegate:(id<DOActionMenuDelegate>)delegate
{
    if (self = [super init])
    {
        [self setDelegate:delegate];
        self.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
        self.layer.cornerRadius = 14;
        self.layer.masksToBounds = YES;
        if (@available(iOS 13.0, *)) {
            self.layer.cornerCurve = kCACornerCurveContinuous;
        }
        [self setItems:items];
    }
    return self;
}

- (void)setItems:(NSArray<DOActionMenuItem *> *)items
{
    _items = items;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self refreshStack];
    });
}

- (void)refreshStack
{
    [self.buttonsView removeFromSuperview];
    self.buttonsView = [[UIStackView alloc] init];
    self.buttonsView.axis = UILayoutConstraintAxisVertical;
    self.buttonsView.translatesAutoresizingMaskIntoConstraints = NO;

    int button_height = [DOGlobalAppearance isHomeButtonDevice] ? UI_ACTION_HEIGHT_HOME_BTN : UI_ACTION_HEIGHT;
    if ([DOGlobalAppearance isSmallDevice])
        button_height = UI_ACTION_HEIGHT_TINY;

    [self.items enumerateObjectsUsingBlock:^(DOActionMenuItem *item, NSUInteger idx, BOOL *stop) {
        DOActionMenuButton *button = [DOActionMenuButton buttonWithItem:item chevron:[self.delegate actionMenuShowsChevronForItem:item]];
        button.enabled = [self.delegate actionMenuItemIsEnabled:item];
        [button setBottomSeparator:idx != self.items.count - 1];
        [self.buttonsView addArrangedSubview:button];
        [NSLayoutConstraint activateConstraints:@[
            [button.heightAnchor constraintEqualToConstant:button_height],
            [button.widthAnchor constraintEqualToAnchor:self.buttonsView.widthAnchor]
        ]];
    }];

    [self addSubview:self.buttonsView];

    int inner_padding = [DOGlobalAppearance isSmallDevice] ? UI_INNER_PADDING_TINY : UI_INNER_PADDING;

    [NSLayoutConstraint activateConstraints:@[
        [self.buttonsView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:inner_padding],
        [self.buttonsView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-inner_padding],
        [self.buttonsView.topAnchor constraintEqualToAnchor:self.topAnchor constant:UI_INNER_TOP_PADDING],
        [self.buttonsView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-UI_INNER_TOP_PADDING],
    ]];
}

- (void)hide
{
    [self setUserInteractionEnabled:NO];
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, -75);
    transform = CGAffineTransformScale(transform, 0.6, 0.6);
    [UIView animateWithDuration:0.3 delay:0.0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self setAlpha:0.0];
        [self setTransform:transform];
    } completion:nil];
}

- (void)show
{
    [self setUserInteractionEnabled:YES];
    [UIView animateWithDuration:0.3 delay:0.0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self setAlpha:1.0];
        [self setTransform:CGAffineTransformIdentity];
    } completion:nil];
}

@end
