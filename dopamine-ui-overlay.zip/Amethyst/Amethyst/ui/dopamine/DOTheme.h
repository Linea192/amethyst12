//
//  DOTheme.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) and tomt000 — MIT License
//  https://github.com/opa334/dopamine
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DOTheme : NSObject

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *key;
@property (nonatomic, retain) UIColor *actionMenuColor;
@property (nonatomic, retain) UIColor *windowColor;
@property (nonatomic, retain) UIImage *image;
@property (nonatomic, assign) float blur;
@property (nonatomic, assign) BOOL titleShadow;

- (id)initWithDictionary:(NSDictionary *)dictionary;

// Drop the lazily cached (blurred) background image so the next -image call
// reloads it from the asset catalog.
- (void)invalidateImageCache;

@end

NS_ASSUME_NONNULL_END
