//
//  DOThemeManager.m
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) and tomt000 — MIT License
//  https://github.com/opa334/dopamine
//

#import "DOThemeManager.h"
#import "../../AppDelegate.h"

@implementation DOThemeManager

+ (instancetype)sharedInstance
{
    static DOThemeManager *sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[DOThemeManager alloc] init];
    });
    return sharedManager;
}

- (id)init
{
    self = [super init];
    if (self) {
        NSMutableArray *themes = [[NSMutableArray alloc] init];

        NSString *path = [[NSBundle mainBundle] pathForResource:@"Themes" ofType:@"plist"];
        NSArray *themeDicts = [NSArray arrayWithContentsOfFile:path];

        for (NSDictionary *dict in themeDicts) {
            DOTheme *newTheme = [[DOTheme alloc] initWithDictionary:dict];
            [themes addObject:newTheme];
        }

        self.themes = [themes copy];
    }
    return self;
}

- (NSArray *)getAvailableThemeKeys
{
    NSMutableArray *keys = [[NSMutableArray alloc] init];
    for (DOTheme *theme in _themes) {
        [keys addObject:theme.key];
    }
    return keys;
}

- (NSArray *)getAvailableThemeNames
{
    NSMutableArray *names = [[NSMutableArray alloc] init];
    for (DOTheme *theme in _themes) {
        [names addObject:theme.name];
    }
    return names;
}

- (DOTheme *)getThemeForKey:(NSString *)key
{
    if (key == nil) return nil;
    NSString *lowerKey = [key lowercaseString];
    for (DOTheme *theme in _themes) {
        if ([theme.key isEqualToString:lowerKey]) {
            return theme;
        }
    }
    return nil;
}

- (DOTheme *)enabledTheme
{
    // Amethyst stores the theme in its own config; legacy names ("Amethyst",
    // "Citrus", "Dusk", "Oxide") map onto the new lowercase keys automatically.
    DOTheme *theme = [self getThemeForKey:amethyst.themeName];
    return theme ?: _themes.firstObject;
}

+ (UIColor *)colorWithAlpha:(float)alpha from:(UIColor *)color
{
    CGFloat red, green, blue, currentAlpha;
    [color getRed:&red green:&green blue:&blue alpha:&currentAlpha];
    return [UIColor colorWithRed:red green:green blue:blue alpha:currentAlpha * alpha];
}

+ (UIColor *)menuColorWithAlpha:(float)alpha
{
    DOTheme *theme = [[DOThemeManager sharedInstance] enabledTheme];
    return [DOThemeManager colorWithAlpha:alpha from:theme.actionMenuColor];
}

+ (UIColor *)windowColorWithAlpha:(float)alpha
{
    DOTheme *theme = [[DOThemeManager sharedInstance] enabledTheme];
    return [DOThemeManager colorWithAlpha:alpha from:theme.windowColor];
}

@end
