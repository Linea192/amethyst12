//
//  DOTransitions.m
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//

#import "DOTransitions.h"

#pragma mark - DOModalBackAction

@implementation DOModalBackAction

- (id)initWithAction:(void (^)(void))action
{
    if (self = [super init])
    {
        self.action = action;
    }
    return self;
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    if (CGRectContainsPoint(self.ignoreFrame, point))
        return NO;
    return [super pointInside:point withEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.action)
        self.action();
}

@end

#pragma mark - DOModalTransitionScale

@interface DOModalTransitionScale ()

@property (nonatomic, assign) BOOL forwards;

@end

@implementation DOModalTransitionScale

- (id)initForwards:(BOOL)forwards {
    self = [super init];
    if (self) {
        _forwards = forwards;
    }
    return self;
}

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.5;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *toViewController = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIViewController *fromViewController = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];

    [[transitionContext containerView] addSubview:toViewController.view];

    float scaleIn = _forwards ? 0.7 : 0.9;
    float scaleOut = _forwards ? 0.9 : 0.7;

    toViewController.view.alpha = 0;
    toViewController.view.transform = CGAffineTransformScale(CGAffineTransformIdentity, scaleIn, scaleIn);

    [UIView animateWithDuration:0.2 animations:^{
        fromViewController.view.alpha = 0;
    }];

    [UIView animateWithDuration:0.6 delay:0.0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        toViewController.view.alpha = 1;
        toViewController.view.transform = CGAffineTransformIdentity;
        fromViewController.view.transform = CGAffineTransformScale(CGAffineTransformIdentity, scaleOut, scaleOut);
    } completion:^(BOOL finished) {
        fromViewController.view.transform = CGAffineTransformIdentity;
        [transitionContext completeTransition:!transitionContext.transitionWasCancelled];
    }];
}

@end

#pragma mark - DOModalTransitionPush

@interface DOModalTransitionPush ()

@property (nonatomic, assign) BOOL forwards;

@end

@implementation DOModalTransitionPush

- (id)initForwards:(BOOL)forwards {
    self = [super init];
    if (self) {
        _forwards = forwards;
    }
    return self;
}

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.5;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *toViewController = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIViewController *fromViewController = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];

    int screen_width = fromViewController.navigationController.view.bounds.size.width;

    [[transitionContext containerView] addSubview:toViewController.view];

    screen_width *= _forwards ? 1 : -1;

    toViewController.view.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, screen_width, 0);
    fromViewController.view.transform = CGAffineTransformIdentity;

    [UIView animateWithDuration:0.6 delay:0.0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        toViewController.view.transform = CGAffineTransformIdentity;
        fromViewController.view.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, -screen_width, 0);
    } completion:^(BOOL finished) {
        fromViewController.view.transform = CGAffineTransformIdentity;
        [transitionContext completeTransition:!transitionContext.transitionWasCancelled];
    }];
}

@end
