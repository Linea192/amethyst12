//
//  DOHeaderView.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DOHeaderView : UIView

- (id)initWithImage:(UIImage *)image subtitles:(NSArray<NSAttributedString *> *)subtitles;

@end

NS_ASSUME_NONNULL_END
