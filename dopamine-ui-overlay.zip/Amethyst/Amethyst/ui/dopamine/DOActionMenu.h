//
//  DOActionMenu.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) and tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Downported to iOS 12: UIAction is replaced by DOActionMenuItem and
//  UIButtonConfiguration by classic UIButton styling.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "DOGlobalAppearance.h"
#import "DOThemeManager.h"

NS_ASSUME_NONNULL_BEGIN

@class DOActionMenuButton;

#pragma mark - Item (UIAction replacement)

@interface DOActionMenuItem : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *imageName; // SF Symbol name (iOS 13+, optional)
@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, copy) void (^handler)(void);

+ (instancetype)itemWithTitle:(NSString *)title image:(nullable NSString *)imageName identifier:(NSString *)identifier handler:(void (^)(void))handler;

@end

#pragma mark - Delegate

@protocol DOActionMenuDelegate <NSObject>

- (BOOL)actionMenuShowsChevronForItem:(DOActionMenuItem *)item;
- (BOOL)actionMenuItemIsEnabled:(DOActionMenuItem *)item;

@end

#pragma mark - Button

@interface DOActionMenuButton : UIButton

@property (nonatomic, retain) DOActionMenuItem *item;
@property (nonatomic) BOOL bottomSeparator;

+ (DOActionMenuButton *)buttonWithItem:(DOActionMenuItem *)item chevron:(BOOL)chevron;

@end

#pragma mark - View

@interface DOActionMenuView : UIView

@property (atomic) UIStackView *buttonsView;
@property (atomic) id<DOActionMenuDelegate> delegate;
@property (nonatomic) NSArray<DOActionMenuItem *> *items;

- (instancetype)initWithItems:(NSArray<DOActionMenuItem *> *)items delegate:(id<DOActionMenuDelegate>)delegate;
- (void)hide;
- (void)show;

@end

NS_ASSUME_NONNULL_END
