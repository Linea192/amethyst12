//
//  UIImage+Blur.m
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) — MIT License
//  https://github.com/opa334/dopamine
//

#import <Foundation/Foundation.h>
#import "UIImage+Blur.h"
#import <CoreImage/CoreImage.h>

@implementation UIImage (Blur)

- (instancetype)imageWithBlur:(float)radius
{
    CIImage *ciImage = [CIImage imageWithCGImage:self.CGImage];
    CIFilter *filter = [CIFilter filterWithName:@"CIGaussianBlur"];
    [filter setDefaults];
    [filter setValue:[ciImage imageByClampingToExtent] forKey:kCIInputImageKey];
    [filter setValue:@(radius) forKey:kCIInputRadiusKey];

    CIImage *outputImage = [[filter outputImage] imageByCroppingToRect:[ciImage extent]];
    CIContext *context   = [CIContext contextWithOptions:nil];
    CGImageRef cgImg     = [context createCGImage:outputImage fromRect:[ciImage extent]];

    return [UIImage imageWithCGImage:cgImg];
}

@end
