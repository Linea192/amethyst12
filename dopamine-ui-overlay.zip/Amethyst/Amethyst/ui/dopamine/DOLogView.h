//
//  DOLogView.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by tomt000 — MIT License
//  https://github.com/opa334/dopamine
//  Contains: DOLogViewProtocol, DOLoadingIndicator, DODoubleHelixIndicator,
//  DOLyricsLogItemView, DOLyricsLogView.
//  The progressive blur was left out (private CAFilter API).
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark - Protocol

@protocol DOLogViewProtocol <NSObject>

- (void)showLog:(NSString *)log;
- (void)didComplete;

@optional
- (void)updateLog:(NSString *)log;
- (void)didFail;

@end

#pragma mark - Indicators

@interface DOLoadingIndicator : UIView
@end

@interface DODoubleHelixIndicator : UIView
@end

#pragma mark - Lyrics log

@interface DOLyricsLogItemView : UIView

@property (nonatomic) UILabel *label;
@property (nonatomic) DOLoadingIndicator *loadingIndicator;
@property (nonatomic) BOOL completed;
@property (nonatomic) UIImpactFeedbackGenerator *feedbackGenerator;

@property (nonatomic) UIImage *completedImage;
@property (nonatomic) UIImage *failedImage;
@property (nonatomic) UIImage *successImage;

- (id)initWithString:(NSString *)string completedImage:(UIImage *)completedImage failedImage:(UIImage *)failedImage successImage:(UIImage *)successImage;
- (void)setCompleted;
- (void)setFailed;
- (void)setSuccess;

@end

@interface DOLyricsLogView : UIView<DOLogViewProtocol>
{
    UIImage *_checkmarkImage;
    UIImage *_exclamationMarkImage;
    UIImage *_unlockedImage;
}

@property (nonatomic, strong) UIStackView *stackView;

@end

NS_ASSUME_NONNULL_END
