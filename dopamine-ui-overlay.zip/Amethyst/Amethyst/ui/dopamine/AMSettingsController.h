//
//  AMSettingsController.h
//  Amethyst (Dopamine UI port)
//
//  New settings screen modeled on Dopamine's settings interface
//  (card layout, dark theme). Original Amethyst popup-card settings
//  replaced; all underlying logic is preserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMSettingsController : UIViewController
@end

NS_ASSUME_NONNULL_END
