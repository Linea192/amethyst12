//
//  UIImage+Blur.h
//  Amethyst (Dopamine UI port)
//
//  Ported from Dopamine by Lars Fröder (opa334) — MIT License
//  https://github.com/opa334/dopamine
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (Blur)

- (instancetype)imageWithBlur:(float)radius;

@end

NS_ASSUME_NONNULL_END
