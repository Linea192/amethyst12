#ifndef Utilities_h
#define Utilities_h

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

// Restyled for the Dopamine look: the app is now dark-only, so the old
// light/dark blur toggles are gone. The public API of every class that the
// jailbreak core talks to (PopupAlert, InstallAlert, LoadingAlert,
// PopupOption switches) is unchanged.

@interface UILabel (extensions)
+ (UILabel *)createLabel:(NSString *)text size:(CGFloat)size bold:(bool)bold align:(NSTextAlignment)align;
@end

@interface UIView (extensions)
+ (UIView *)createSeprator:(BOOL)unused;
@end

@interface PopupOption : NSObject
@property (nonatomic, strong) UIView *optionView;
@property (nonatomic, strong) UILabel *optionTitle;
@property (nonatomic, strong) UISwitch *optionSwitch;
@property (nonatomic, strong) UIButton *optionButton;
@property (nonatomic, strong) UIView *separator;

- (id)initSwitchOption:(NSString *)title;
- (void)showSeprator:(BOOL)val;
- (BOOL)getSwitchValue;
- (void)setSwitchValue:(BOOL)val;
- (void)setSwitchCallback:(id)_id _sel:(SEL)_sel;
@end

@interface PopupAlert : NSObject
@property (nonatomic, strong) UIView *alertView;
@property (nonatomic, strong) UIView *alertOverlay;
@property (nonatomic, strong) UILabel *alertTitle;
@property (nonatomic, strong) UILabel *alertMessage;
@property (nonatomic, strong) UIButton *alertButton;
@property (nonatomic, strong) UIView *separator;

- (id)init:(NSString *)title message:(NSString *)message button:(NSString *)button _id:(id)_id _sel:(SEL)_sel;
- (void)setText:(NSString *)title message:(NSString *)message button:(NSString *)button;
- (void)setAction:(id)_id _sel:(SEL)_sel;
- (void)setOverlay:(UIView *)view;
- (void)openAlert;
- (void)closeAlert;
- (BOOL)isOpen;
@end

@interface InstallAlert : NSObject
@property (nonatomic, strong) UIView *alertView;
@property (nonatomic, strong) UIView *alertOverlay;
@property (nonatomic, strong) UILabel *alertTitle;
@property (nonatomic, strong) UILabel *alertMessage;
@property (nonatomic, strong) UIButton *alertButton;
@property (nonatomic, strong) PopupOption *installSileo;
@property (nonatomic, strong) PopupOption *installZebra;
@property (nonatomic, strong) UIView *separator;
@property (nonatomic, assign) BOOL selectionDone;

- (id)init;
- (void)setOverlay:(UIView *)view;
- (void)openAlert;
- (void)closeAlert;
- (BOOL)isOpen;
@end

@interface LoadingAlert : NSObject
@property (nonatomic, strong) UIView *alertView;
@property (nonatomic, strong) UIView *alertOverlay;
@property (nonatomic, strong) UILabel *alertTitle;
@property (nonatomic, strong) UIView *separator;
@property (nonatomic, strong) UIActivityIndicatorView *indicator;

- (id)init:(NSString *)title;
- (void)setOverlay:(UIView *)view;
- (void)openAlert;
- (void)closeAlert;
- (BOOL)isOpen;
@end

#endif /* Utilities_h */
