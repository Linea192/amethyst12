#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
#import <CoreText/CoreText.h>
#import <mach-o/dyld.h>
#import "../AppDelegate.h"
#import "MainController.h"
#import "../jailbreak/jailbreak.h"
#import "dopamine/DOGlobalAppearance.h"
#import "dopamine/DOThemeManager.h"
#import "dopamine/DONavigationController.h"
#import "dopamine/AMSettingsController.h"

MainController *mainController = NULL;
void (^alertCallback)(void) = NULL;
extern int jbserver_heartbeat(void);
void jbserver_post_jailbreak(bool root, bool unsandbox);
int run_jbutil(char *cmd, char *arg, bool wait);
extern int sandbox_check(pid_t pid, const char *operation, uint32_t type, ...);
extern int csops(pid_t pid, unsigned int ops, void *useraddr, size_t usersize);
int run_binary(char *path, char **args, char **env, bool wait, bool root);

@implementation MainController

#pragma mark - State

- (BOOL)prefersStatusBarHidden {
    return self.hideStatusBar;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        return UIInterfaceOrientationMaskAllButUpsideDown;
    }
    return UIInterfaceOrientationMaskPortrait;
}

- (BOOL)shouldAutorotate {
    return ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad);
}

- (BOOL)prefersHomeIndicatorAutoHidden {
    return self.hideHomeIndicator;
}

- (void)setHideStatusBar:(BOOL)hideStatusBar {
    _hideStatusBar = hideStatusBar;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void)setHideHomeIndicator:(BOOL)hideHomeIndicator {
    _hideHomeIndicator = hideHomeIndicator;
    if (@available(iOS 13.0, *)) {
        [self setNeedsUpdateOfHomeIndicatorAutoHidden];
    }
}

- (bool)deviceSupported {
    int version = [[[UIDevice currentDevice] systemVersion] intValue];
    return (version == 12 || version == 13);
}

- (bool)deviceJailbroken {
    if (self.isJailbroken == -1) {
        if (jbserver_heartbeat() == 0x1337 ||
            sandbox_check(getpid(), NULL, 0, NULL) == 0 ||
            access("/", R_OK | W_OK) == 0) {
            goto jailbroken;
        }

        void *handle = dlopen("/usr/lib/libjailbreak.dylib", RTLD_NOW);
        if (handle != NULL) {
            void *fix_setuid = dlsym(handle, "jb_oneshot_fix_setuid_now");
            void *entitle_now = dlsym(handle, "jb_oneshot_entitle_now");
            dlclose(handle);
            if (fix_setuid != NULL || entitle_now != NULL) {
                goto jailbroken;
            }
        }

        mach_port_t tfp0 = MACH_PORT_NULL;
        host_get_special_port(mach_host_self(), HOST_LOCAL_NODE, 4, &tfp0);
        if (!MACH_PORT_VALID(tfp0)) task_for_pid(mach_task_self(), 0, &tfp0);

        if (MACH_PORT_VALID(tfp0)) {
            mach_port_deallocate(mach_task_self(), tfp0);
            goto jailbroken;
        }

        uint32_t cs_flags = 0;
        if (csops(getpid(), 0, &cs_flags, 4) == 0) {
            if (cs_flags & 0x04000000) {
                goto jailbroken;
            }
        }

        uint32_t image_count = _dyld_image_count();
        for (int i = 0; i < image_count; i++) {
            const char *name = _dyld_get_image_name(i);
            if (strcmp(name, "/usr/lib/base_hook.dylib") == 0 ||
                strcmp(name, "/usr/lib/pspawn_payload.dylib") == 0 ||
                strcmp(name, "/usr/lib/pspawn_payload-stg2.dylib") == 0) {
                goto jailbroken;
            }
        }

        self.isJailbroken = 0;
        return false;

jailbroken:
        self.isJailbroken = 1;
        jbserver_post_jailbreak(false, false);
        return true;
    }
    return (self.isJailbroken == 1);
}

#pragma mark - View

- (void)loadView {
    [super loadView];
    mainController = self;
    self.hideStatusBar = false;
    self.hideHomeIndicator = false;
    self.isJailbroken = -1;
    [self setNeedsStatusBarAppearanceUpdate];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(logProgress:) name:@"status" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fadeDisplay:) name:@"fade" object:nil];

    self.view.backgroundColor = [UIColor clearColor];
    [self setupStack];

    // Alerts (same bridge the jailbreak C code talks to)
    self.alertOverlay = [[UIView alloc] init];
    self.alertOverlay.translatesAutoresizingMaskIntoConstraints = NO;
    self.alertOverlay.backgroundColor = [UIColor blackColor];
    self.alertOverlay.userInteractionEnabled = NO;
    self.alertOverlay.frame = self.view.frame;
    self.alertOverlay.alpha = 0.0f;
    [self.view addSubview:self.alertOverlay];

    self.installAlert = [[InstallAlert alloc] init];
    [self.view addSubview:self.installAlert.alertView];
    [self.installAlert setOverlay:self.alertOverlay];
    [self constrainAlertView:self.installAlert.alertView];

    self.loadingAlert = [[LoadingAlert alloc] init:@"Refreshing Icon Cache"];
    [self.view addSubview:self.loadingAlert.alertView];
    [self.loadingAlert setOverlay:self.alertOverlay];
    [self constrainAlertView:self.loadingAlert.alertView];

    self.alert = [[PopupAlert alloc] init:@"" message:@"" button:@"" _id:self _sel:@selector(alertHandler)];
    [self.view addSubview:self.alert.alertView];
    [self.alert setOverlay:self.alertOverlay];
    [self constrainAlertView:self.alert.alertView];
}

- (void)constrainAlertView:(UIView *)alertView
{
    [NSLayoutConstraint activateConstraints:@[
        [alertView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [alertView.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
        [alertView.widthAnchor constraintEqualToConstant:280.0],
    ]];
}

// Dopamine-style main screen: header, action menu card, jailbreak button
- (void)setupStack
{
    UIStackView *stackView = [[UIStackView alloc] init];
    [stackView setAxis:UILayoutConstraintAxisVertical];
    [stackView setAlignment:UIStackViewAlignmentTrailing];
    [stackView setDistribution:UIStackViewDistributionEqualSpacing];
    [stackView setTranslatesAutoresizingMaskIntoConstraints:NO];

    [self.view addSubview:stackView];

    int statusBarHeight = fmax(15, [[UIApplication sharedApplication] keyWindow].safeAreaInsets.top - 20);

    [NSLayoutConstraint activateConstraints:@[
        [stackView.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor constant:statusBarHeight],
        [stackView.heightAnchor constraintEqualToAnchor:self.view.heightAnchor multiplier:[DOGlobalAppearance isHomeButtonDevice] ? 0.78 : 0.73]
    ]];

    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        NSLayoutConstraint *relativeWidthConstraint = [stackView.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:0.8];
        relativeWidthConstraint.priority = UILayoutPriorityDefaultHigh;
        NSLayoutConstraint *maxWidthConstraint = [stackView.widthAnchor constraintLessThanOrEqualToConstant:UI_IPAD_MAX_WIDTH];
        maxWidthConstraint.priority = UILayoutPriorityRequired;

        [NSLayoutConstraint activateConstraints:@[
            relativeWidthConstraint,
            maxWidthConstraint,
            [stackView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor]
        ]];
    }
    else
    {
        [NSLayoutConstraint activateConstraints:@[
            [stackView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:UI_PADDING],
            [stackView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-UI_PADDING],
        ]];
    }

    // Header
    self.headerView = [[DOHeaderView alloc] initWithImage:[UIImage imageNamed:@"Dopamine"] subtitles:@[
        [DOGlobalAppearance mainSubtitleString:@"iOS 12.0 - 13.7 (arm64)"],
        [DOGlobalAppearance secondarySubtitleString:@"by staturnz, UI by opa334"],
    ]];

    [stackView addArrangedSubview:self.headerView];

    [NSLayoutConstraint activateConstraints:@[
        [self.headerView.leadingAnchor constraintEqualToAnchor:stackView.leadingAnchor constant:5],
        [self.headerView.trailingAnchor constraintEqualToAnchor:stackView.trailingAnchor]
    ]];

    // Action Menu
    self.actionView = [[DOActionMenuView alloc] initWithItems:@[
        [DOActionMenuItem itemWithTitle:@"Settings" image:@"gearshape" identifier:@"settings" handler:^{
            [self.navigationController pushViewController:[[AMSettingsController alloc] init] animated:YES];
        }],
        [DOActionMenuItem itemWithTitle:@"Restart SpringBoard" image:@"arrow.clockwise" identifier:@"respring" handler:^{
            [self respringDevice];
        }],
        [DOActionMenuItem itemWithTitle:@"Reboot Userspace" image:@"arrow.clockwise.circle" identifier:@"reboot-userspace" handler:^{
            [self userspaceReboot];
        }],
        [DOActionMenuItem itemWithTitle:@"Credits" image:@"info.circle" identifier:@"credits" handler:^{
            [self.navigationController pushViewController:[[CreditsController alloc] init] animated:YES];
        }],
    ] delegate:self];

    [stackView addArrangedSubview:self.actionView];

    [NSLayoutConstraint activateConstraints:@[
        [self.actionView.leadingAnchor constraintEqualToAnchor:stackView.leadingAnchor],
        [self.actionView.trailingAnchor constraintEqualToAnchor:stackView.trailingAnchor],
    ]];

    UIView *buttonPlaceHolder = [[UIView alloc] init];
    [buttonPlaceHolder setTranslatesAutoresizingMaskIntoConstraints:NO];
    [stackView addArrangedSubview:buttonPlaceHolder];
    [NSLayoutConstraint activateConstraints:@[
        [buttonPlaceHolder.heightAnchor constraintEqualToConstant:60]
    ]];

    // Jailbreak Button
    BOOL isJailbroken = [self deviceJailbroken];
    BOOL isSupported = [self deviceSupported];

    NSString *jailbreakButtonTitle = [self jailbreakButtonTitle];

    NSString *jailbreakButtonImageName;
    if (isSupported)
        jailbreakButtonImageName = @"lock.open";
    else
        jailbreakButtonImageName = @"lock.slash";

    self.jailbreakBtn = [[DOJailbreakButton alloc] initWithItem:[DOActionMenuItem itemWithTitle:jailbreakButtonTitle image:jailbreakButtonImageName identifier:@"jailbreak" handler:^{
        [self startJailbreak];
    }]];
    self.jailbreakBtn.enabled = !isJailbroken && isSupported;

    [self.view addSubview:self.jailbreakBtn];

    [NSLayoutConstraint activateConstraints:(self.jailbreakButtonConstraints = @[
        [self.jailbreakBtn.leadingAnchor constraintEqualToAnchor:stackView.leadingAnchor],
        [self.jailbreakBtn.trailingAnchor constraintEqualToAnchor:stackView.trailingAnchor],
        [self.jailbreakBtn.heightAnchor constraintEqualToAnchor:buttonPlaceHolder.heightAnchor],
        [self.jailbreakBtn.centerYAnchor constraintEqualToAnchor:buttonPlaceHolder.centerYAnchor]
    ])];
}

- (NSString *)jailbreakButtonTitle
{
    BOOL isJailbroken = [self deviceJailbroken];
    BOOL isSupported = [self deviceSupported];

    NSString *jailbreakButtonTitle = @"Jailbreak";
    if (!isSupported)
        jailbreakButtonTitle = @"Unsupported";
    else if (isJailbroken)
        jailbreakButtonTitle = @"Jailbroken";
    else if (self.restoreRootfsEnabled)
        jailbreakButtonTitle = @"Restore RootFS";

    return jailbreakButtonTitle;
}

- (void)refreshJailbreakButtonTitle
{
    [self.jailbreakBtn.button setTitle:[self jailbreakButtonTitle] forState:UIControlStateNormal];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self refreshJailbreakButtonTitle];
}

#pragma mark - Jailbreak (Amethyst logic, unchanged)

- (void)startJailbreak
{
    if (self.jailbreakBtn.didExpand) return;

    [self.actionView hide];
    [self.jailbreakBtn expandButton:self.jailbreakButtonConstraints];
    self.hideHomeIndicator = YES;

    [UIView animateWithDuration:0.75 delay:0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.headerView setTransform:CGAffineTransformMakeTranslation(0, -25)];
    } completion:nil];

    uint32_t flags = JB_FLAG_NONE;

    if (self.restoreRootfsEnabled) flags |= JB_FLAG_RESTORE_ROOTFS;
    if (amethyst.enableTweaks) flags |= JB_FLAG_ENABLE_TWEAKS;
    if (amethyst.exploit == Exploit_Hemlock) {
        flags |= JB_FLAG_EXPLOIT_HEMLOCK;
    } else {
        flags |= JB_FLAG_EXPLOIT_TRIGON;
    }

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        jb_error_t err = run_jailbreak(flags, (char *)[amethyst.generator UTF8String]);
        dispatch_async(dispatch_get_main_queue(), ^{
            alertCallback = ^(){};
            if (err == JB_ERROR_REMOUNT_REBOOT || err == JB_ERROR_RESTORE_REBOOT) {
                alertCallback = ^() {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self fadeToBlack:^{
                            reboot(0);
                            for (uint32_t i = 0; i < 10; i++) {
                                usleep(100000);
                                sync();
                            }
                        }];
                    });
                };
            } else if (err != JB_ERROR_SUCCESS) {
                if (self.jailbreakBtn.logView != nil) {
                    [self.jailbreakBtn.logView didFail];
                }
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self resetJailbreakUI];
                });
            }

            if (err != JB_ERROR_SUCCESS) {
                [self.alert setText:[self getErrorTitle:err] message:[self getErrorMessage:err] button:[self getErrorButton:err]];
                [self.alert setAction:self _sel:@selector(alertHandler)];
                [self.alert openAlert];
            }
        });
    });
}

- (void)resetJailbreakUI
{
    self.hideHomeIndicator = NO;
    [self.jailbreakBtn collapseButton:self.jailbreakButtonConstraints];
    [self.actionView show];
    [UIView animateWithDuration:0.5 delay:0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.headerView setTransform:CGAffineTransformIdentity];
    } completion:nil];
}

#pragma mark - Error mapping (unchanged Amethyst logic)

- (NSString *)getErrorTitle:(jb_error_t)err {
    switch (err) {
        case JB_ERROR_SUCCESS: return @"Jailbreak Done";
        case JB_ERROR_REMOUNT_REBOOT: return @"Reboot Required";
        case JB_ERROR_RESTORE_REBOOT: return @"Reboot Required";
        case JB_ERROR_RESTORE: return @"Restore Failed";
        case JB_ERROR_OTA: return @"Unable to Continue";
        case JB_ERROR_UNSUPPORTED_INSTALL: return @"Restore RootFS Required";
        default: return @"Jailbreak Failed";
    }
}

- (NSString *)getErrorButton:(jb_error_t)err {
    switch (err) {
        case JB_ERROR_REMOUNT_REBOOT: return @"Reboot";
        case JB_ERROR_RESTORE_REBOOT: return @"Reboot";
        default: return @"Okay";
    }
}

- (NSString *)getErrorMessage:(jb_error_t)err {
    switch (err) {
        case JB_ERROR_SUCCESS: return @"Jailbreak Done";
        case JB_ERROR_EXPLOIT: return @"Kernel exploit failed. Reboot the device before attempting to jailbreak again.";
        case JB_ERROR_PERMISSION: return @"Failed to initialize permissions.";
        case JB_ERROR_PATCHFINDER: return @"Failed to find required system patches and offsets";
        case JB_ERROR_TRUSTCACHE: return @"Failed to initialize trustcache.";
        case JB_ERROR_PPL: return @"Failed to initialize the PPL bypass.";
        case JB_ERROR_REMOUNT: return @"Failed to remount RootFS.";
        case JB_ERROR_RESTORE: return @"Failed to restore RootFS.";
        case JB_ERROR_OTA: return @"OTA Update file is already mounted. Delete the update before attempting to jailbreak again.";
        case JB_ERROR_REMOUNT_REBOOT: return @"A reboot is required to continue with the jailbreak process. After the device reboots, run the jailbreak again.";
        case JB_ERROR_RESTORE_REBOOT: return @"A reboot is required to complete the RootFS restore.";
        case JB_ERROR_HANDOFF: return @"Failed to handoff the jailbreak server to launchd.";
        case JB_ERROR_DYLD: return @"Failed to apply patches to dyld.";
        case JB_ERROR_BOOTSTRAP: return @"Failed to install bootstrap.";
        case JB_ERROR_SILEO: return @"Failed to install Sileo.";
        case JB_ERROR_ZEBRA: return @"Failed to install Zebra.";
        case JB_ERROR_LIBSWIFT: return @"Failed to install libswift.";
        case JB_ERROR_UNSUPPORTED_INSTALL: return @"An unsupported jailbreak is currently installed on this device. Restore RootFS before attempting to jailbreak again.";
        default: return @"An unknown error has occurred";
    }
}

#pragma mark - Settings bridge (used by AMSettingsController)

- (void)handleEnableTweaks:(BOOL)enabled {
    if ([self isJailbroken]) {
        jbserver_post_jailbreak(true, true);
        if (enabled) {
            unlink("/amethyst/.disable_tweaks");
        } else {
            FILE *file = fopen("/amethyst/.disable_tweaks", "w+");
            fflush(file);
            fclose(file);
        }
        sync();
    }

    amethyst.enableTweaks = enabled;
    [amethyst saveConfig];
}

- (void)setRestoreRootfsEnabled:(BOOL)enabled {
    self.restoreRootfsEnabled = enabled;
    [self refreshJailbreakButtonTitle];
}

- (void)changeExploit:(AmethystExploitOption)exploitOption {
    amethyst.exploit = exploitOption;
    [amethyst saveConfig];
}

- (void)saveGeneratorValue:(NSString *)value {
    amethyst.generator = value;
    [amethyst saveConfig];
}

- (void)applyTheme:(NSString *)themeKey {
    amethyst.themeName = themeKey;
    [amethyst saveConfig];

    // Rebuild the whole UI with the new theme (Dopamine relaunches here too)
    UIWindow *window = ((AppDelegate *)[UIApplication sharedApplication].delegate).window;
    if (window != nil) {
        window.rootViewController = nil;
        window.rootViewController = [[DONavigationController alloc] init];
        [window makeKeyAndVisible];
    }
}

#pragma mark - Utilities (unchanged Amethyst logic)

- (void)userspaceReboot {
    if (![self isJailbroken] || ![self deviceSupported]) return;
    jbserver_post_jailbreak(false, true);

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        usleep(500000);
        run_jbutil("--userspace-reboot", NULL, true);
    });
    [self fadeToBlack:^{}];
}

- (void)respringDevice {
    if (![self isJailbroken] || ![self deviceSupported]) return;
    jbserver_post_jailbreak(false, true);

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        usleep(500000);
        run_jbutil("--respring", NULL, true);
    });
    [self fadeToBlack:^{}];
}

- (void)refreshIconCache {
    if (![self isJailbroken] || ![self deviceSupported]) return;
    jbserver_post_jailbreak(false, true);

    mainController.loadingAlert.alertView.alpha = 0.01;
    [mainController.loadingAlert openAlert];

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        usleep(500000);
        char *args[] = {"/usr/bin/uicache", "--all", NULL};
        char *env[] = {"DYLD_INSERT_LIBRARIES=/usr/lib/base_hook.dylib", NULL};
        run_binary("/usr/bin/uicache", args, env, true, false);

        dispatch_async(dispatch_get_main_queue(), ^{
            [self.loadingAlert closeAlert];
            mainController.loadingAlert.alertView.alpha = 0.00;
        });
    });
}

- (void)alertHandler {
    [self.alert closeAlert];
    if (alertCallback != NULL) {
        alertCallback();
        alertCallback = NULL;
    }
}

- (void)sendPopupAlert:(NSString *)title message:(NSString *)message button:(NSString *)button {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.alert setText:title message:message button:button];
        [self.alert setAction:self _sel:@selector(alertHandler)];
        [self.alert openAlert];
    });
}

#pragma mark - Notifications

- (void)logProgress:(NSNotification *)noti {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *label = noti.userInfo[@"msg"][0];
        UIView<DOLogViewProtocol> *logView = self.jailbreakBtn.logView;
        if (logView == nil) return;

        if ([label isEqualToString:@"Done"]) {
            [logView didComplete];
        } else {
            [logView showLog:label];
        }
    });
}

- (void)fadeDisplay:(NSNotification *)noti {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self fadeToBlack:^{}];
    });
}

// Dopamine-style fade to black
- (void)fadeToBlack:(void (^)(void))completion
{
    static bool didFade = false;
    if (didFade)
        return;
    didFade = true;

    UIView *mainView = self.navigationController.view;
    if (mainView == nil) mainView = self.view;

    float deviceCornerRadius = [[[UIScreen mainScreen] valueForKey:@"_displayCornerRadius"] floatValue];

    if (deviceCornerRadius > 0) {
        mainView.layer.cornerRadius = deviceCornerRadius;
        if (@available(iOS 13.0, *)) {
            mainView.layer.cornerCurve = kCACornerCurveContinuous;
        }
        mainView.layer.masksToBounds = YES;
    }

    self.hideStatusBar = YES;

    [UIView animateWithDuration:0.5 delay:0 usingSpringWithDamping:0.9 initialSpringVelocity:2.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        mainView.transform = CGAffineTransformMakeScale(0.9, 0.9);
        mainView.alpha = 0.0;
    } completion:^(BOOL success) {
        if (completion != nil) completion();
    }];
}

#pragma mark - Action Menu Delegate

- (BOOL)actionMenuShowsChevronForItem:(DOActionMenuItem *)item
{
    if ([item.identifier isEqualToString:@"settings"] || [item.identifier isEqualToString:@"credits"]) return YES;
    return NO;
}

- (BOOL)actionMenuItemIsEnabled:(DOActionMenuItem *)item
{
    if ([item.identifier isEqualToString:@"respring"] || [item.identifier isEqualToString:@"reboot-userspace"]) {
        return [self deviceJailbroken];
    }
    return YES;
}

@end

#pragma mark - C bridge (unchanged, used by the jailbreak core)

void ProgressLog(float progress, const char *fmt, ...) {
    char buf[1024] = {0};
    va_list args = NULL;

    va_start(args, fmt);
    vsprintf(buf, fmt, args);
    va_end(args);

    NSDictionary *data = @{
        @"progress": @[[NSNumber numberWithFloat:progress]],
        @"msg": @[[NSString stringWithUTF8String:buf]]
    };
    [[NSNotificationCenter defaultCenter] postNotificationName:@"status" object:nil userInfo:data];
}

char *get_app_version(void) {
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    if (version == NULL) return NULL;

    const char *version_str = [version UTF8String];
    if (version_str == NULL) return NULL;
    return strdup(version_str);
}

void FadeDisplay(void) {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"fade" object:NULL userInfo:NULL];
}

void ShowAlert(const char *title, const char *msg, const char *btn, void (^action)(void)) {
    NSString *titleString = [NSString stringWithUTF8String:title];
    NSString *msgString = [NSString stringWithUTF8String:msg];
    NSString *btnString = [NSString stringWithUTF8String:btn];

    alertCallback = action;
    [mainController sendPopupAlert:titleString message:msgString button:btnString];
}

uint32_t get_install_options(void) {
    __block uint32_t flags = 0;
    dispatch_async(dispatch_get_main_queue(), ^{
        mainController.installAlert.alertView.alpha = 0.01;
        [mainController.installAlert openAlert];
    });

    while (!mainController.installAlert.selectionDone) {}
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([mainController.installAlert.installSileo getSwitchValue]) flags |= JB_FLAG_INSTALL_SILEO;
        if ([mainController.installAlert.installZebra getSwitchValue]) flags |= JB_FLAG_INSTALL_ZEBRA;
    });

    usleep(10000);
    return flags;
}
