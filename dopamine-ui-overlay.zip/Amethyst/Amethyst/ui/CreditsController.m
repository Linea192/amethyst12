#import "../AppDelegate.h"
#import "Utilities.h"
#import "CreditsController.h"
#import "dopamine/DOGlobalAppearance.h"
#import "dopamine/DOThemeManager.h"

#define addCredit(name, _detail, link) [[CreditsInfo alloc] init:@name detail:@_detail linkUrl:@link]

@implementation CreditsInfo
- (id)init:(NSString *)name detail:(NSString *)detail linkUrl:(NSString *)linkUrl {
    self = [super init];
    self.userName = name;
    self.userDetail = detail;
    self.linkUrl = linkUrl;
    return self;
}
@end

@implementation CreditsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableData = @[
        addCredit("staturnz", "Main Developer", "https://github.com/staturnzz"),
        addCredit("Alfie CG", "Trigon", "https://github.com/alfiecg24"),
        addCredit("Clarity", "Various techniques", "https://github.com/TheRealClarity"),
        addCredit("xerus", "Logo, Icon, Designs", "https://x.com/xerusdesign"),
        addCredit("felix-pb", "puaf_physpuppet", "https://github.com/felix-pb"),
        addCredit("opa334", "Various techniques, Dopamine UI", "https://github.com/opa334"),
        addCredit("tomt000", "Dopamine UI", "https://github.com/tomt000"),
        addCredit("xerub", "Patchfinder base", "https://github.com/xerub"),
        addCredit("oct0xor", "Operation Triangulation", "https://github.com/oct0xor"),
        addCredit("kucher1n", "Operation Triangulation", "https://x.com/kucher1n"),
        addCredit("bzvr_", "Operation Triangulation", "https://x.com/bzvr_"),
        addCredit("Procursus", "Bootstrap", "https://github.com/ProcursusTeam"),
        addCredit("Zebra Team", "Zebra", "https://github.com/zbrateam"),
        addCredit("Sileo Team", "Sileo", "https://github.com/Sileo")
    ];

    self.view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.35];

    [self setupBackButton];
    [self setupTitle];

    // Card containing the table
    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [DOThemeManager menuColorWithAlpha:1.0];
    card.layer.cornerRadius = 14;
    card.layer.masksToBounds = YES;
    if (@available(iOS 13.0, *)) {
        card.layer.cornerCurve = kCACornerCurveContinuous;
    }
    [self.view addSubview:card];

    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.allowsMultipleSelection = NO;
    self.tableView.rowHeight = 50.0f;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorColor = [[UIColor whiteColor] colorWithAlphaComponent:0.1];
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20);
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [card addSubview:self.tableView];

    [NSLayoutConstraint activateConstraints:@[
        [card.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:UI_PADDING],
        [card.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-UI_PADDING],
        [card.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:60],
        [card.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-20],

        [self.tableView.leadingAnchor constraintEqualToAnchor:card.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:card.trailingAnchor],
        [self.tableView.topAnchor constraintEqualToAnchor:card.topAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:card.bottomAnchor],
    ]];
}

- (void)setupBackButton
{
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.translatesAutoresizingMaskIntoConstraints = NO;
    [backButton setTitle:@"Amethyst" forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor colorWithWhite:1 alpha:0.8] forState:UIControlStateNormal];
    backButton.titleLabel.font = [UIFont systemFontOfSize:17];

    UIImage *chevron = [DOGlobalAppearance smallIconImageNamed:@"chevron.left"];
    if (chevron != nil) {
        [backButton setImage:chevron forState:UIControlStateNormal];
        backButton.titleEdgeInsets = UIEdgeInsetsMake(0, 8, 0, -8);
        backButton.tintColor = [UIColor colorWithWhite:1 alpha:0.8];
    } else {
        [backButton setTitle:@"\u2039 Amethyst" forState:UIControlStateNormal];
    }

    [backButton addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:backButton];
    [NSLayoutConstraint activateConstraints:@[
        [backButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:20],
        [backButton.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:15],
        [backButton.heightAnchor constraintEqualToConstant:30],
    ]];
}

- (void)goBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setupTitle
{
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = @"Credits";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:30 weight:UIFontWeightSemibold];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [titleLabel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:12],
    ]];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableData.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    CreditsInfo *creditsInfo = self.tableData[indexPath.row];
    if ([creditsInfo.linkUrl isEqualToString:@""]) return;
    NSURL *linkUrl = [NSURL URLWithString:creditsInfo.linkUrl];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [[UIApplication sharedApplication] openURL:linkUrl options:@{} completionHandler:NULL];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"creditCell"];
    if (cell == NULL) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"creditCell"];

    CreditsInfo *creditsInfo = self.tableData[indexPath.row];
    cell.textLabel.text = creditsInfo.userName;
    cell.detailTextLabel.text = creditsInfo.userDetail;
    cell.backgroundColor = [UIColor clearColor];
    cell.detailTextLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.75];
    cell.textLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.95];

    UIView *selectedView = [[UIView alloc] init];
    selectedView.layer.cornerRadius = 15;
    selectedView.layer.masksToBounds = YES;
    selectedView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.2f];
    [cell setSelectedBackgroundView:selectedView];
    return cell;
}
@end
