#!/bin/bash
# Build Amethyst.ipa - CI-robust, self-contained version.
# 1) Builds basebins (jailbreak helper binaries) from source -> basebins.tar
# 2) Builds the app with -project/-target (no scheme resolution needed)
# Captures full logs; validates every stage.
set -e
set -o pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"
echo "== repo root: $ROOT =="

echo "== tool preflight =="
if ! command -v ldid >/dev/null; then
  brew install ldid
fi
if ! command -v dpkg-deb >/dev/null; then
  brew install dpkg
fi
if ! command -v llvm-objcopy >/dev/null; then
  OBJC=$(xcrun --find llvm-objcopy 2>/dev/null || true)
  if [ -n "$OBJC" ]; then
    sudo ln -sf "$OBJC" /usr/local/bin/llvm-objcopy
  else
    brew install llvm
    sudo ln -sf /opt/homebrew/opt/llvm/bin/llvm-objcopy /usr/local/bin/llvm-objcopy
  fi
fi
echo "ldid:          $(command -v ldid)"
echo "dpkg-deb:      $(command -v dpkg-deb)"
echo "llvm-objcopy:  $(command -v llvm-objcopy)"
xcodebuild -version

echo "== building basebins (helper binaries) =="
cd "$ROOT/basebins"
if ! make package 2>&1 | tee "$ROOT/basebins.log"; then
  echo "== make package failed; retrying with -Werror relaxed =="
  find . -maxdepth 2 -name Makefile -exec sed -i.bak 's/ -Werror / /g' {} +
  find . -maxdepth 2 -name Makefile.bak -delete
  make package 2>&1 | tee "$ROOT/basebins-retry.log"
fi
if [ ! -e basebins.tar ]; then
  echo "ERROR: basebins.tar was not produced"
  exit 1
fi
ls -la basebins.tar tnsv2_updater.deb tnsv2_updater_stub.deb

echo "== building app =="
cd "$ROOT/Amethyst"
rm -rf ./build Amethyst.ipa xcodebuild.log
xcodebuild clean build \
  -project Amethyst.xcodeproj \
  -target Amethyst \
  -sdk iphoneos \
  -configuration Release \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  2>&1 | tee xcodebuild.log

APP=$(find build -name Amethyst.app -type d | head -1)
if [ -z "$APP" ]; then
  echo "ERROR: Amethyst.app not found in build output"
  exit 1
fi
echo "== app bundle: $APP =="

strip "$APP/Amethyst"
ldid -S "$APP/Amethyst"

mkdir -p build/Payload
mv "$APP" build/Payload/
ditto -c -k --sequesterRsrc --keepParent build/Payload Amethyst.ipa

echo "== DONE: $ROOT/Amethyst/Amethyst.ipa =="
ls -la Amethyst.ipa
