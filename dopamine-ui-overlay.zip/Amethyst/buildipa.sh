#!/bin/bash
# Build Amethyst.ipa — CI-robust version.
# Uses -project/-target (no scheme or destination resolution needed),
# captures the full xcodebuild log, and validates every stage.
set -e
set -o pipefail

cd "$(dirname "$0")"
rm -rf ./build Amethyst.ipa xcodebuild.log

echo "== xcodebuild version =="
xcodebuild -version

echo "== Building (project/target mode) =="
xcodebuild clean build \
  -project Amethyst.xcodeproj \
  -target Amethyst \
  -sdk iphoneos \
  -configuration Release \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  2>&1 | tee xcodebuild.log

APP=$(find build -name Amethyst.app -type d | head -1)
if [ -z "$APP" ]; then
  echo "ERROR: Amethyst.app not found in build output"
  exit 1
fi
echo "== App bundle: $APP =="

strip "$APP/Amethyst"
ldid -S "$APP/Amethyst"

mkdir -p build/Payload
mv "$APP" build/Payload/
ditto -c -k --sequesterRsrc --keepParent build/Payload Amethyst.ipa

echo "== DONE: $(pwd)/Amethyst.ipa =="
ls -la Amethyst.ipa
